import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import {
  Menu, X, Sparkles, ArrowDown, Send, Mail, MapPin, Phone,
  ArrowUpRight, ExternalLink, Heart, CheckCircle, ChevronRight,
  Zap, Brain, Palette, BarChart3, PenTool, Settings, Bot, GraduationCap, MessageSquare,
} from 'lucide-react';

/* ═══════════════════════════════════════════════════════════════
   GRADIENT TEXT HELPER
   ═══════════════════════════════════════════════════════════════ */
const ACCENT = '#8b5cf6';
const SECONDARY = '#ec4899';
const GRADIENT = `linear-gradient(135deg, ${ACCENT}, ${SECONDARY})`;

function GText({ children }: { children: React.ReactNode }) {
  return (
    <span
      style={{
        background: GRADIENT,
        backgroundSize: '200% 200%',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
        backgroundClip: 'text',
      }}
    >
      {children}
    </span>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: NAVBAR
   ═══════════════════════════════════════════════════════════════ */
const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Portfolio', href: '#portfolio' },
  { label: 'Contact', href: '#contact' },
];

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-dark/80 backdrop-blur-xl border-b border-dark-border/50'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <motion.a href="#home" className="flex items-center gap-2 group" whileHover={{ scale: 1.02 }}>
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: GRADIENT }}
              >
                <span className="text-white font-bold text-lg">DP</span>
              </div>
              <span className="text-text-primary font-semibold text-xl tracking-tight">
                Ude Favour<span style={{ color: ACCENT }}>.</span>
              </span>
            </motion.a>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="px-4 py-2 text-sm text-text-secondary hover:text-text-primary transition-colors duration-300 rounded-lg hover:bg-white/5"
                >
                  {link.label}
                </a>
              ))}
            </div>

            {/* CTA */}
            <div className="hidden md:flex items-center gap-4">
              <motion.a
                href="https://wa.link/270sxo"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="px-6 py-2.5 text-white text-sm font-medium rounded-full hover:shadow-lg transition-shadow duration-300"
                style={{ background: GRADIENT, boxShadow: `0 4px 20px ${ACCENT}40` }}
              >
                Book a Call
              </motion.a>
            </div>

            {/* Mobile Toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 text-text-secondary hover:text-text-primary transition-colors"
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-dark/95 backdrop-blur-xl pt-24 px-6"
          >
            <div className="flex flex-col gap-2">
              {navLinks.map((link, i) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="px-4 py-4 text-2xl font-medium text-text-secondary hover:text-text-primary border-b border-dark-border/50 transition-colors"
                >
                  {link.label}
                </motion.a>
              ))}
              <motion.a
                href="https://wa.link/270sxo"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileOpen(false)}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="mt-6 px-8 py-4 text-white text-lg font-medium rounded-full text-center"
                style={{ background: GRADIENT }}
              >
                Book a Call
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: HERO
   ═══════════════════════════════════════════════════════════════ */
function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden noise-bg"
    >
      {/* Background orbs */}
      <div className="glow-orb w-[500px] h-[500px] top-[-10%] left-[-10%]" style={{ backgroundColor: `${ACCENT}30` }} />
      <div className="glow-orb w-[400px] h-[400px] bottom-[-5%] right-[-5%]" style={{ backgroundColor: `${SECONDARY}20`, animationDelay: '2s' }} />
      <div className="glow-orb w-[300px] h-[300px] top-[50%] left-[50%]" style={{ backgroundColor: `${ACCENT}15`, animationDelay: '1s' }} />

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
        backgroundSize: '60px 60px'
      }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 text-center">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8"
          style={{ backgroundColor: `${ACCENT}15`, border: `1px solid ${ACCENT}30` }}
        >
          <Sparkles size={14} style={{ color: ACCENT }} />
          <span className="text-sm font-medium" style={{ color: ACCENT }}>Available for projects & consultations</span>
        </motion.div>

        {/* Main heading */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[0.95] mb-6"
        >
          <span className="text-text-primary">I engineer</span>
          <br />
          <GText>precision prompts</GText>
          <br />
          <span className="text-text-primary">that deliver results.</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.25 }}
          className="max-w-3xl mx-auto text-lg md:text-xl text-text-secondary leading-relaxed mb-12"
        >
          A prompt engineer specializing in crafting high-performance prompts that unlock the full potential of large language models — helping businesses automate smarter, communicate clearer, and scale faster.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <motion.a
            href="https://wa.link/270sxo"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="px-8 py-4 text-white font-semibold rounded-full transition-all duration-300 text-lg flex items-center gap-2"
            style={{ background: GRADIENT, boxShadow: `0 8px 30px ${ACCENT}40` }}
          >
            <MessageSquare size={20} />
            Book a Consultation
          </motion.a>
          <motion.a
            href="#portfolio"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="px-8 py-4 border border-dark-border text-text-primary font-semibold rounded-full hover:bg-white/5 hover:border-text-muted transition-all duration-300 text-lg"
          >
            View My Work
          </motion.a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="flex flex-col items-center gap-2 text-text-muted"
        >
          <span className="text-xs tracking-widest uppercase">Scroll</span>
          <ArrowDown size={16} />
        </motion.div>
      </motion.div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: MARQUEE / SCROLLING TICKER
   ═══════════════════════════════════════════════════════════════ */
const marqueeItems = [
  'Prompt Engineering', 'GPT-4o', 'Claude', 'Prompt Chaining', 'AI Automation',
  'Few-Shot Prompting', 'Custom GPTs', 'LangChain', 'System Prompts', 'Gemini',
  'Chain-of-Thought', 'RAG Pipelines', 'AI Agents', 'Prompt Optimization',
  'OpenAI API', 'Conversational AI', 'Zero-Shot Prompting', 'Fine-Tuning',
  'AI Strategy', 'Python', 'Chatbot Design', 'Context Engineering',
  'Workflow Automation', 'AI Consulting', 'Copilot', 'Data Extraction',
  'Vector Databases', 'Instruction Design', 'Knowledge Systems',
  'AI Copywriting', 'Perplexity', 'Make / Zapier',
];

function Marquee() {
  const doubled = [...marqueeItems, ...marqueeItems];

  return (
    <div className="py-8 bg-dark-secondary border-y border-dark-border overflow-hidden">
      <motion.div
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
        className="flex items-center gap-8 whitespace-nowrap"
      >
        {doubled.map((item, i) => (
          <span key={i} className="flex items-center gap-8">
            <span className="text-lg font-medium text-text-muted">{item}</span>
            <span className="text-sm" style={{ color: ACCENT }}>✦</span>
          </span>
        ))}
      </motion.div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: ABOUT
   ═══════════════════════════════════════════════════════════════ */
const techStack = [
  'ChatGPT', 'GPT-4o', 'Claude', 'Gemini', 'Midjourney', 'DALL·E',
  'Stable Diffusion', 'OpenAI API', 'LangChain', 'Custom GPTs', 'Python',
  'RAG', 'Vector Databases', 'Zapier', 'Notion', 'AI Copilot',
  'Prompt Chaining', 'AI Agents', 'Fine-Tuning',
];

const skillCards = [
  {
    icon: <Brain size={24} />,
    title: 'Prompt Engineering',
    description: 'System prompts, few-shot, chain-of-thought',
  },
  {
    icon: <Settings size={24} />,
    title: 'AI Workflow Design',
    description: 'Agents, chains, automated pipelines',
  },
  {
    icon: <Palette size={24} />,
    title: 'AI Content & Image Generation',
    description: 'Midjourney, DALL·E, Stable Diffusion',
  },
  {
    icon: <BarChart3 size={24} />,
    title: 'AI Strategy & Consulting',
    description: 'Model selection, optimization, integration',
  },
];

function About() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section id="about" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[400px] h-[400px] top-[20%] right-[-10%]" style={{ backgroundColor: `${ACCENT}15` }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: ACCENT }}>About Me</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            Passionate about engineering
            <br />
            <GText>smarter AI interactions</GText>.
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left — Story */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="space-y-6"
          >
            <p className="text-lg text-text-secondary leading-relaxed">
              Hi, I'm <span className="text-text-primary font-semibold">Ude Favour</span> — a prompt engineer based in Nigeria. With hands-on experience working with large language models, I help businesses, creators, and teams unlock the full potential of AI. From crafting precision system prompts to designing end-to-end AI-powered workflows, I specialize in turning vague ideas into structured, high-performing prompts that deliver consistent, reliable results. I've worked across industries including tech, marketing, education, and e-commerce — always with one goal: making AI actually useful.
            </p>
            <p className="text-lg text-text-secondary leading-relaxed">
              I believe the gap between a mediocre AI output and an exceptional one is never the model — it's the prompt. My approach is rooted in clarity, structure, and deep understanding of how language models think. Every prompt I engineer is intentional. I obsess over token efficiency, output consistency, and edge-case handling because details matter. Whether I'm building a custom GPT, designing a multi-step prompt chain, or optimizing an existing AI workflow, I treat every project as a system to be architected — not just a sentence to be written.
            </p>

            {/* Location & Experience */}
            <div className="flex flex-wrap gap-4 pt-2">
              <div className="flex items-center gap-2 text-text-muted">
                <MapPin size={16} style={{ color: ACCENT }} />
                <span className="text-sm">Abakaliki, Nigeria</span>
              </div>
              <div className="flex items-center gap-2 text-text-muted">
                <Zap size={16} style={{ color: ACCENT }} />
                <span className="text-sm">Prompt Engineer | High-Ticket Sales Closer</span>
              </div>
            </div>

            {/* Tech stack */}
            <div className="pt-6">
              <h3 className="text-sm font-medium text-text-muted uppercase tracking-widest mb-4">Tech Stack</h3>
              <div className="flex flex-wrap gap-2">
                {techStack.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1.5 text-sm text-text-secondary bg-dark-card border border-dark-border rounded-lg hover:border-accent/50 hover:text-accent transition-all duration-300 cursor-default"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right — Skill Cards */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="grid grid-cols-2 gap-4"
          >
            {skillCards.map((skill, i) => (
              <motion.div
                key={skill.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
                className="gradient-border p-6 rounded-xl card-hover group cursor-default"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 group-hover:opacity-90 transition-colors"
                  style={{ backgroundColor: `${ACCENT}15`, color: ACCENT }}
                >
                  {skill.icon}
                </div>
                <h3 className="text-text-primary font-semibold mb-1">{skill.title}</h3>
                <p className="text-sm text-text-muted">{skill.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: SERVICES
   ═══════════════════════════════════════════════════════════════ */
const services = [
  {
    icon: <PenTool size={28} />,
    title: 'Custom Prompt Design',
    description: 'I build tailored prompts from scratch that align with your brand voice and goals, ensuring consistent, high-quality AI outputs every time.',
    features: ['Brand-Aligned Prompts', 'System Prompt Architecture', 'Multi-Model Support', 'Output Consistency'],
  },
  {
    icon: <Zap size={28} />,
    title: 'Prompt Optimization',
    description: 'I audit and refine your existing prompts to improve accuracy, reduce hallucinations, and cut token costs for better performance.',
    features: ['Prompt Auditing', 'Hallucination Reduction', 'Token Cost Optimization', 'Accuracy Improvement'],
  },
  {
    icon: <Settings size={28} />,
    title: 'AI Workflow Automation',
    description: 'I design prompt-driven workflows that automate repetitive tasks like content creation, data extraction, and reporting to save you time.',
    features: ['Content Automation', 'Data Extraction', 'Automated Reporting', 'Pipeline Design'],
  },
  {
    icon: <Bot size={28} />,
    title: 'Chatbot/Agent Development',
    description: 'I engineer system prompts and dialogue flows that power natural, on-brand conversational AI experiences for your users.',
    features: ['System Prompt Design', 'Dialogue Flow Engineering', 'Custom GPT Agents', 'Conversational UX'],
  },
  {
    icon: <GraduationCap size={28} />,
    title: 'Training & Consultation',
    description: 'I teach your team prompt engineering best practices so they can confidently and effectively work with AI on their own.',
    features: ['Team Workshops', 'Best Practices Guide', 'Hands-on Training', '1-on-1 Mentoring'],
  },
];

function Services() {
  const { ref, isInView } = useInView(0.1);

  return (
    <section id="services" className="relative py-32 bg-dark-secondary noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] bottom-[-10%] left-[-10%]" style={{ backgroundColor: `${SECONDARY}15` }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: ACCENT }}>Services</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            What I <GText>do best</GText>.
          </h2>
          <p className="max-w-3xl mx-auto text-lg text-text-secondary mt-6">
            I craft, optimize, and refine AI prompts that turn vague inputs into precise, high-quality outputs. By leveraging techniques like chain-of-thought reasoning, few-shot learning, and iterative testing, I help businesses and individuals get the most out of AI tools — saving time, reducing errors, and maximizing results.
          </p>
        </motion.div>

        {/* Services Grid — first 4 in 2x2, last one full-width */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {services.slice(0, 4).map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 + i * 0.1 }}
              className="group relative bg-dark-card border border-dark-border rounded-2xl p-8 card-hover overflow-hidden"
            >
              {/* Hover gradient bg */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
                style={{ background: `linear-gradient(135deg, ${ACCENT}08, ${SECONDARY}08)` }}
              />

              <div className="relative z-10">
                <div className="flex items-start justify-between mb-6">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300"
                    style={{ backgroundColor: `${ACCENT}15`, color: ACCENT }}
                  >
                    {service.icon}
                  </div>
                  <ArrowUpRight size={20} className="text-text-muted group-hover:text-accent transition-colors duration-300" />
                </div>

                <h3 className="text-xl font-bold text-text-primary mb-3">{service.title}</h3>
                <p className="text-text-secondary leading-relaxed mb-6">{service.description}</p>

                <div className="flex flex-wrap gap-2">
                  {service.features.map((feat) => (
                    <span
                      key={feat}
                      className="px-3 py-1 text-xs font-medium text-text-muted bg-dark border border-dark-border rounded-full"
                    >
                      {feat}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* 5th service — full width */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.55 }}
          className="group relative bg-dark-card border border-dark-border rounded-2xl p-8 card-hover overflow-hidden"
        >
          <div
            className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
            style={{ background: `linear-gradient(135deg, ${ACCENT}08, ${SECONDARY}08)` }}
          />
          <div className="relative z-10 md:flex md:items-start md:gap-8">
            <div className="shrink-0 mb-6 md:mb-0">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300"
                style={{ backgroundColor: `${ACCENT}15`, color: ACCENT }}
              >
                {services[4].icon}
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-xl font-bold text-text-primary">{services[4].title}</h3>
                <ArrowUpRight size={20} className="text-text-muted group-hover:text-accent transition-colors duration-300 shrink-0 ml-4" />
              </div>
              <p className="text-text-secondary leading-relaxed mb-6">{services[4].description}</p>
              <div className="flex flex-wrap gap-2">
                {services[4].features.map((feat) => (
                  <span
                    key={feat}
                    className="px-3 py-1 text-xs font-medium text-text-muted bg-dark border border-dark-border rounded-full"
                  >
                    {feat}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: PORTFOLIO / PROOF OF WORK
   ═══════════════════════════════════════════════════════════════ */
function Portfolio() {
  const { ref, isInView } = useInView(0.1);

  return (
    <section id="portfolio" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] top-[30%] right-[-15%]" style={{ backgroundColor: `${ACCENT}15` }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: ACCENT }}>Portfolio</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            My <GText>proof of work</GText>.
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-text-secondary mt-6">
            Explore my complete portfolio of prompt engineering projects, case studies, AI workflow designs, and more — all documented and organized in one place.
          </p>
        </motion.div>

        {/* Notion Portfolio Link — MAIN CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-3xl mx-auto"
        >
          {/* Big Notion Card */}
          <a
            href="https://www.notion.so/invite/59083c0bdc56760a8dd2e5d45af43f7abcbcd8bf"
            target="_blank"
            rel="noopener noreferrer"
            className="group block relative"
          >
            {/* Glow behind card */}
            <div
              className="absolute inset-0 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-500"
              style={{ background: GRADIENT }}
            />

            <div className="relative bg-dark-card border border-dark-border rounded-3xl p-10 md:p-14 text-center card-hover overflow-hidden">
              {/* Decorative gradient top bar */}
              <div className="absolute top-0 left-0 right-0 h-1 rounded-t-3xl" style={{ background: GRADIENT }} />

              {/* Notion icon */}
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-white mb-8">
                <span className="text-black font-bold text-3xl">N</span>
              </div>

              <h3 className="text-2xl md:text-3xl font-bold text-text-primary mb-4">
                View My Complete Portfolio
              </h3>
              <p className="text-text-secondary leading-relaxed mb-8 max-w-xl mx-auto">
                My full proof of work is documented on Notion — including prompt engineering projects, custom GPT builds, AI workflow designs, client case studies, and detailed breakdowns of my process and results.
              </p>

              <div
                className="inline-flex items-center gap-3 px-8 py-4 text-white font-semibold rounded-full text-lg transition-all duration-300 group-hover:shadow-2xl"
                style={{ background: GRADIENT, boxShadow: `0 8px 30px ${ACCENT}30` }}
              >
                Open Portfolio on Notion
                <ExternalLink size={20} />
              </div>

              <div className="flex items-center justify-center gap-6 mt-10 pt-8 border-t border-dark-border/50">
                <div className="flex items-center gap-2 text-text-muted text-sm">
                  <ChevronRight size={14} style={{ color: ACCENT }} />
                  <span>Prompt Engineering Projects</span>
                </div>
                <div className="flex items-center gap-2 text-text-muted text-sm">
                  <ChevronRight size={14} style={{ color: ACCENT }} />
                  <span>Custom GPT Builds</span>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-text-muted text-sm">
                  <ChevronRight size={14} style={{ color: ACCENT }} />
                  <span>AI Workflow Designs</span>
                </div>
              </div>
            </div>
          </a>
        </motion.div>

        {/* Skill showcase cards below */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-12"
        >
          {[
            { gradient: 'linear-gradient(135deg, #8b5cf6, #6d28d9)', title: 'System Prompts', desc: 'Precision-crafted prompts for LLMs with structured output control' },
            { gradient: 'linear-gradient(135deg, #ec4899, #be185d)', title: 'Custom GPTs', desc: 'Purpose-built GPTs tailored to specific business workflows' },
            { gradient: 'linear-gradient(135deg, #3b82f6, #1d4ed8)', title: 'Prompt Chains', desc: 'Multi-step prompt architectures for complex AI tasks' },
            { gradient: 'linear-gradient(135deg, #10b981, #047857)', title: 'AI Automation', desc: 'End-to-end automated workflows powered by intelligent prompts' },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.5 + i * 0.1 }}
              className="group bg-dark-card border border-dark-border rounded-xl p-5 card-hover"
            >
              <div className="h-3 w-16 rounded-full mb-4" style={{ background: item.gradient }} />
              <h3 className="text-base font-bold text-text-primary mb-2 group-hover:text-accent transition-colors">{item.title}</h3>
              <p className="text-text-muted text-xs leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: CONTACT
   ═══════════════════════════════════════════════════════════════ */
function Contact() {
  const { ref, isInView } = useInView(0.1);
  const [submitted, setSubmitted] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    if (formRef.current) formRef.current.reset();
    setTimeout(() => setSubmitted(false), 4000);
  };

  const contactInfo = [
    { icon: <Mail size={20} />, label: 'Email', value: 'udefavour447@gmail.com', href: 'mailto:udefavour447@gmail.com' },
    { icon: <Phone size={20} />, label: 'Phone', value: '08147012132', href: 'tel:08147012132' },
    { icon: <MapPin size={20} />, label: 'Location', value: 'Abakaliki, Nigeria', href: '#' },
  ];

  const socials = [
    { name: 'Instagram', url: 'https://www.instagram.com/desparkking?igsh=eHJmcDJlencwMThi' },
    { name: 'LinkedIn', url: 'https://www.linkedin.com/in/ude-favour-640a732a7' },
    { name: 'Twitter / X', url: 'https://x.com/desparkking' },
    { name: 'WhatsApp', url: 'https://wa.link/270sxo' },
  ];

  return (
    <section id="contact" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] bottom-[-20%] right-[-10%]" style={{ backgroundColor: `${ACCENT}20` }} />
      <div className="glow-orb w-[300px] h-[300px] top-[10%] left-[-5%]" style={{ backgroundColor: `${SECONDARY}15`, animationDelay: '2s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: ACCENT }}>Contact</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            Let's work <GText>together</GText>.
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-text-secondary mt-6">
            Have a project in mind? Need smarter AI prompts for your business? Let's discuss how I can help you unlock the full power of AI.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-2 space-y-8"
          >
            <div className="space-y-6">
              {contactInfo.map((info) => (
                <a
                  key={info.label}
                  href={info.href}
                  className="flex items-start gap-4 group"
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-all duration-300"
                    style={{ backgroundColor: `${ACCENT}15`, color: ACCENT }}
                  >
                    {info.icon}
                  </div>
                  <div>
                    <p className="text-sm text-text-muted">{info.label}</p>
                    <p className="text-text-primary font-medium group-hover:text-accent transition-colors">{info.value}</p>
                  </div>
                </a>
              ))}
            </div>

            {/* Social Links */}
            <div className="pt-8 border-t border-dark-border">
              <h3 className="text-sm font-medium text-text-muted uppercase tracking-widest mb-4">Follow Me</h3>
              <div className="flex flex-wrap gap-3">
                {socials.map((social) => (
                  <a
                    key={social.name}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2.5 bg-dark-card border border-dark-border rounded-xl text-sm text-text-secondary hover:border-accent/50 hover:text-accent transition-all duration-300 group"
                  >
                    {social.name}
                    <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                ))}
              </div>
            </div>

            {/* WhatsApp CTA */}
            <div className="pt-8 border-t border-dark-border">
              <a
                href="https://wa.link/270sxo"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 px-6 py-4 rounded-xl text-white font-semibold transition-all duration-300 hover:shadow-lg"
                style={{ background: GRADIENT, boxShadow: `0 4px 20px ${ACCENT}30` }}
              >
                <MessageSquare size={20} />
                Book a Free Consultation
                <ArrowUpRight size={16} />
              </a>
              <p className="text-xs text-text-muted mt-3">Quick response via WhatsApp</p>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="lg:col-span-3"
          >
            <form
              ref={formRef}
              onSubmit={handleSubmit}
              className="bg-dark-card border border-dark-border rounded-2xl p-8 space-y-6"
            >
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">Name</label>
                  <input
                    type="text"
                    placeholder="Your name"
                    className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">Email</label>
                  <input
                    type="email"
                    placeholder="your@email.com"
                    className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">Subject</label>
                <input
                  type="text"
                  placeholder="e.g., Prompt Engineering for my SaaS product"
                  className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">Message</label>
                <textarea
                  rows={5}
                  placeholder="Tell me about your project, goals, and how AI can help..."
                  className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all resize-none"
                  required
                />
              </div>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-4 text-white font-semibold rounded-xl hover:shadow-lg transition-shadow flex items-center justify-center gap-2"
                style={{ background: GRADIENT, boxShadow: `0 4px 20px ${ACCENT}30` }}
              >
                {submitted ? (
                  <>
                    <CheckCircle size={20} />
                    Message Sent!
                  </>
                ) : (
                  <>
                    <Send size={18} />
                    Send Message
                  </>
                )}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION: FOOTER
   ═══════════════════════════════════════════════════════════════ */
function Footer() {
  return (
    <footer className="relative bg-dark-secondary border-t border-dark-border py-16 noise-bg">
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: GRADIENT }}>
              <span className="text-white font-bold text-lg">DP</span>
            </div>
            <span className="text-text-primary font-semibold text-xl tracking-tight">
              Ude Favour<span style={{ color: ACCENT }}>.</span>
            </span>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap items-center justify-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm text-text-secondary hover:text-text-primary transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Back to top */}
          <motion.a
            href="#home"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-5 py-2.5 border border-dark-border rounded-full text-sm text-text-secondary hover:text-text-primary hover:border-text-muted transition-all"
          >
            ↑ Back to top
          </motion.a>
        </div>

        <div className="mt-12 pt-8 border-t border-dark-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-text-muted flex items-center gap-1">
            © {new Date().getFullYear()} Ude Favour. Made with <Heart size={14} className="fill-pink-500 text-pink-500" /> and precision prompts.
          </p>
          <p className="text-sm text-text-muted">
            Prompt Engineer | High-Ticket Sales Closer | Tech Enthusiast
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ═══════════════════════════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════════════════════════ */
export function App() {
  return (
    <div className="min-h-screen bg-dark text-text-primary">
      <Navbar />
      <Hero />
      <Marquee />
      <About />
      <Services />
      <Portfolio />
      <Contact />
      <Footer />
    </div>
  );
}
