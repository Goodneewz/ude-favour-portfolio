import { motion } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import { Code2, Palette, Zap, Globe } from 'lucide-react';

const skills = [
  { icon: <Code2 size={24} />, title: 'Frontend Dev', desc: 'React, Next.js, TypeScript' },
  { icon: <Palette size={24} />, title: 'UI/UX Design', desc: 'Figma, Design Systems' },
  { icon: <Zap size={24} />, title: 'Performance', desc: 'Optimization & Speed' },
  { icon: <Globe size={24} />, title: 'Full Stack', desc: 'Node.js, APIs, DBs' },
];

const techStack = [
  'React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Node.js',
  'Figma', 'Framer Motion', 'PostgreSQL', 'GraphQL', 'AWS',
  'Docker', 'Git',
];

export function About() {
  const { ref, isInView } = useInView(0.2);

  return (
    <section id="about" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[400px] h-[400px] bg-accent/10 top-[20%] right-[-10%]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <span className="text-accent text-sm font-medium uppercase tracking-widest">About Me</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            Passionate about creating
            <br />
            <span className="gradient-text">meaningful experiences</span>.
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left — Story */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="space-y-6"
          >
            <p className="text-lg text-text-secondary leading-relaxed">
              Hi, I'm <span className="text-text-primary font-semibold">Alex Chen</span> — a creative developer based in
              San Francisco. With over 5 years of experience, I bridge the gap between design and
              development to create products that are not only visually stunning but also highly
              functional and performant.
            </p>
            <p className="text-lg text-text-secondary leading-relaxed">
              I believe in the power of clean code and thoughtful design. Every project I take on
              is an opportunity to push boundaries and deliver something exceptional. From startups
              to enterprise solutions, I bring the same level of passion and attention to detail.
            </p>

            {/* Tech stack */}
            <div className="pt-6">
              <h3 className="text-sm font-medium text-text-muted uppercase tracking-widest mb-4">Tech Stack</h3>
              <div className="flex flex-wrap gap-2">
                {techStack.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1.5 text-sm text-text-secondary bg-dark-card border border-dark-border rounded-lg hover:border-accent/50 hover:text-accent transition-all duration-300 cursor-default"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right — Skill Cards */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="grid grid-cols-2 gap-4"
          >
            {skills.map((skill, i) => (
              <motion.div
                key={skill.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
                className="gradient-border p-6 rounded-xl card-hover group cursor-default"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center text-accent mb-4 group-hover:bg-accent/20 transition-colors">
                  {skill.icon}
                </div>
                <h3 className="text-text-primary font-semibold mb-1">{skill.title}</h3>
                <p className="text-sm text-text-muted">{skill.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
