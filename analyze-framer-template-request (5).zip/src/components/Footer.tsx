import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

const footerLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Work', href: '#work' },
  { label: 'Contact', href: '#contact' },
];

export function Footer() {
  return (
    <footer className="relative bg-dark-secondary border-t border-dark-border py-16 noise-bg">
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent to-pink-500 flex items-center justify-center">
              <span className="text-white font-bold text-lg">A</span>
            </div>
            <span className="text-text-primary font-semibold text-xl tracking-tight">
              Alex<span className="text-accent">.</span>dev
            </span>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap items-center justify-center gap-6">
            {footerLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm text-text-secondary hover:text-text-primary transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Back to top */}
          <motion.a
            href="#home"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-5 py-2.5 border border-dark-border rounded-full text-sm text-text-secondary hover:text-text-primary hover:border-text-muted transition-all"
          >
            ↑ Back to top
          </motion.a>
        </div>

        <div className="mt-12 pt-8 border-t border-dark-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-text-muted flex items-center gap-1">
            © {new Date().getFullYear()} Alex.dev. Made with <Heart size={14} className="text-pink-500 fill-pink-500" /> and lots of coffee.
          </p>
          <p className="text-sm text-text-muted">
            Designed & Developed by Alex Chen
          </p>
        </div>
      </div>
    </footer>
  );
}
