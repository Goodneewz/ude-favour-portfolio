import { motion } from 'framer-motion';

const marqueeItems = [
  'Web Development', '✦', 'UI/UX Design', '✦', 'React', '✦', 'TypeScript', '✦',
  'Next.js', '✦', 'Framer Motion', '✦', 'Tailwind CSS', '✦', 'Performance', '✦',
  'Web Development', '✦', 'UI/UX Design', '✦', 'React', '✦', 'TypeScript', '✦',
  'Next.js', '✦', 'Framer Motion', '✦', 'Tailwind CSS', '✦', 'Performance', '✦',
];

export function Marquee() {
  return (
    <div className="py-8 bg-dark-secondary border-y border-dark-border overflow-hidden">
      <motion.div
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        className="flex items-center gap-8 whitespace-nowrap"
      >
        {marqueeItems.map((item, i) => (
          <span
            key={i}
            className={`text-lg font-medium ${
              item === '✦' ? 'text-accent text-sm' : 'text-text-muted'
            }`}
          >
            {item}
          </span>
        ))}
      </motion.div>
    </div>
  );
}
