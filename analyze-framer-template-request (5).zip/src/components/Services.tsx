import { motion } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import { Monitor, Smartphone, Layers, TrendingUp, ArrowUpRight } from 'lucide-react';

const services = [
  {
    icon: <Monitor size={28} />,
    title: 'Web Development',
    description: 'Building responsive, fast, and scalable web applications using modern technologies like React, Next.js, and TypeScript.',
    features: ['Single Page Apps', 'Progressive Web Apps', 'E-commerce Platforms', 'CMS Integration'],
  },
  {
    icon: <Smartphone size={28} />,
    title: 'Mobile Development',
    description: 'Cross-platform mobile applications that provide native-like experiences with React Native and modern frameworks.',
    features: ['iOS & Android', 'Cross-platform', 'App Store Deployment', 'Push Notifications'],
  },
  {
    icon: <Layers size={28} />,
    title: 'UI/UX Design',
    description: 'User-centered design that combines aesthetics with usability to create delightful digital experiences.',
    features: ['User Research', 'Wireframing', 'Prototyping', 'Design Systems'],
  },
  {
    icon: <TrendingUp size={28} />,
    title: 'Performance Optimization',
    description: 'Making your existing applications faster, more accessible, and optimized for search engines.',
    features: ['Core Web Vitals', 'SEO Optimization', 'Accessibility', 'Bundle Analysis'],
  },
];

export function Services() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section id="services" className="relative py-32 bg-dark-secondary noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] bg-pink-500/10 bottom-[-10%] left-[-10%]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-accent text-sm font-medium uppercase tracking-widest">Services</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            What I <span className="gradient-text">do best</span>.
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-text-secondary mt-6">
            I offer a comprehensive range of services to help bring your digital vision to life.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 + i * 0.1 }}
              className="group relative bg-dark-card border border-dark-border rounded-2xl p-8 card-hover overflow-hidden"
            >
              {/* Hover gradient bg */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />

              <div className="relative z-10">
                <div className="flex items-start justify-between mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-accent/10 flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all duration-300">
                    {service.icon}
                  </div>
                  <ArrowUpRight size={20} className="text-text-muted group-hover:text-accent transition-colors duration-300" />
                </div>

                <h3 className="text-xl font-bold text-text-primary mb-3">{service.title}</h3>
                <p className="text-text-secondary leading-relaxed mb-6">{service.description}</p>

                <div className="flex flex-wrap gap-2">
                  {service.features.map((feat) => (
                    <span
                      key={feat}
                      className="px-3 py-1 text-xs font-medium text-text-muted bg-dark border border-dark-border rounded-full"
                    >
                      {feat}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
