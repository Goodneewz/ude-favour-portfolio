import { motion } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah Mitchell',
    role: 'CEO at TechVentures',
    content: 'Alex completely transformed our web presence. The attention to detail and the performance of the final product exceeded all our expectations. A true professional.',
    rating: 5,
    avatar: 'SM',
    color: 'from-violet-500 to-purple-600',
  },
  {
    name: 'David Park',
    role: 'Founder at Startify',
    content: 'Working with Alex was an absolute pleasure. They understood our vision from day one and delivered a product that truly represents our brand. Highly recommended!',
    rating: 5,
    avatar: 'DP',
    color: 'from-pink-500 to-rose-600',
  },
  {
    name: 'Emma Rodriguez',
    role: 'Product Manager at Innovate Co',
    content: 'The design system Alex built for us has been a game-changer. Our development speed increased by 40% and our product looks more consistent than ever.',
    rating: 5,
    avatar: 'ER',
    color: 'from-blue-500 to-cyan-600',
  },
];

export function Testimonials() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section id="testimonials" className="relative py-32 bg-dark-secondary noise-bg" ref={ref}>
      <div className="glow-orb w-[400px] h-[400px] bg-accent/10 top-[10%] left-[-5%]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-accent text-sm font-medium uppercase tracking-widest">Testimonials</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            What clients <span className="gradient-text">say</span>.
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-text-secondary mt-6">
            Don't just take my word for it — hear from the people I've worked with.
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, i) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 + i * 0.15 }}
              className="group bg-dark-card border border-dark-border rounded-2xl p-8 card-hover relative"
            >
              {/* Quote icon */}
              <Quote size={40} className="text-accent/10 absolute top-6 right-6" />

              {/* Stars */}
              <div className="flex gap-1 mb-6">
                {Array.from({ length: testimonial.rating }).map((_, j) => (
                  <Star key={j} size={16} className="fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              {/* Content */}
              <p className="text-text-secondary leading-relaxed mb-8 relative z-10">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${testimonial.color} flex items-center justify-center`}>
                  <span className="text-white text-sm font-bold">{testimonial.avatar}</span>
                </div>
                <div>
                  <h4 className="text-text-primary font-semibold">{testimonial.name}</h4>
                  <p className="text-text-muted text-sm">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
