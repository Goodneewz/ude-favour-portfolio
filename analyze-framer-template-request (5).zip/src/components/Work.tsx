import { motion } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: 'Lumina Dashboard',
    category: 'Web Application',
    description: 'A comprehensive analytics dashboard with real-time data visualization, dark mode, and responsive design for SaaS platforms.',
    tags: ['React', 'TypeScript', 'D3.js', 'Tailwind'],
    image: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    featured: true,
  },
  {
    title: 'Meridian E-Commerce',
    category: 'E-Commerce',
    description: 'Full-stack e-commerce platform with Stripe integration, inventory management, and a seamless checkout experience.',
    tags: ['Next.js', 'Prisma', 'Stripe', 'PostgreSQL'],
    image: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    featured: true,
  },
  {
    title: 'Pulse Social App',
    category: 'Mobile App',
    description: 'A social networking application with real-time messaging, stories, and AI-powered content recommendations.',
    tags: ['React Native', 'Firebase', 'ML Kit'],
    image: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
    featured: false,
  },
  {
    title: 'Nova Design System',
    category: 'Design System',
    description: 'A comprehensive design system with 60+ components, accessibility-first approach, and thorough documentation.',
    tags: ['Figma', 'Storybook', 'React', 'CSS'],
    image: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
    featured: false,
  },
  {
    title: 'Zenith Landing Page',
    category: 'Website',
    description: 'A high-converting SaaS landing page with smooth animations, optimized performance, and A/B testing integration.',
    tags: ['Next.js', 'Framer Motion', 'Vercel'],
    image: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    featured: false,
  },
  {
    title: 'DataFlow API',
    category: 'Backend',
    description: 'RESTful API service with GraphQL support, real-time webhooks, rate limiting, and comprehensive documentation.',
    tags: ['Node.js', 'GraphQL', 'Redis', 'Docker'],
    image: 'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
    featured: false,
  },
];

export function Work() {
  const { ref, isInView } = useInView(0.1);

  return (
    <section id="work" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] bg-blue-500/10 top-[30%] right-[-15%]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row md:items-end md:justify-between mb-16"
        >
          <div>
            <span className="text-accent text-sm font-medium uppercase tracking-widest">Portfolio</span>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
              Selected <span className="gradient-text">works</span>.
            </h2>
          </div>
          <p className="max-w-md text-text-secondary mt-4 md:mt-0">
            A curated selection of projects that showcase my expertise in design and development.
          </p>
        </motion.div>

        {/* Featured Projects */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {projects.filter(p => p.featured).map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 + i * 0.1 }}
              className="group relative bg-dark-card border border-dark-border rounded-2xl overflow-hidden card-hover"
            >
              {/* Image */}
              <div
                className="h-64 w-full relative overflow-hidden"
                style={{ background: project.image }}
              >
                <div className="absolute inset-0 bg-dark/20 group-hover:bg-dark/10 transition-colors duration-500" />
                <div className="absolute bottom-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/30 transition-colors">
                    <Github size={18} />
                  </button>
                  <button className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/30 transition-colors">
                    <ExternalLink size={18} />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <span className="text-xs font-medium text-accent uppercase tracking-wider">{project.category}</span>
                <h3 className="text-xl font-bold text-text-primary mt-2 mb-2">{project.title}</h3>
                <p className="text-text-secondary text-sm leading-relaxed mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map(tag => (
                    <span key={tag} className="px-2.5 py-1 text-xs font-medium text-text-muted bg-dark border border-dark-border rounded-md">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Other Projects Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {projects.filter(p => !p.featured).map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
              className="group bg-dark-card border border-dark-border rounded-xl p-5 card-hover"
            >
              <div
                className="h-3 w-16 rounded-full mb-4"
                style={{ background: project.image }}
              />
              <span className="text-xs font-medium text-accent uppercase tracking-wider">{project.category}</span>
              <h3 className="text-base font-bold text-text-primary mt-1 mb-2 group-hover:text-accent transition-colors">{project.title}</h3>
              <p className="text-text-muted text-xs leading-relaxed mb-3">{project.description}</p>
              <div className="flex flex-wrap gap-1.5">
                {project.tags.slice(0, 3).map(tag => (
                  <span key={tag} className="px-2 py-0.5 text-[10px] font-medium text-text-muted bg-dark border border-dark-border rounded">
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
