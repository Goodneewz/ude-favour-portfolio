import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, X, Star, Info, Link as LinkIcon } from 'lucide-react';

/* ─── Section Title ─── */
export function SectionTitle({ step, title, highlight, subtitle }: {
  step: number;
  title: string;
  highlight: string;
  subtitle: string;
}) {
  return (
    <div className="mb-10">
      <span className="text-accent text-xs font-semibold uppercase tracking-[0.2em] mb-3 block">
        Step {step}
      </span>
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-text-primary leading-tight mb-4">
        {title} <span className="gradient-text">{highlight}</span>
      </h1>
      <p className="text-lg text-text-secondary leading-relaxed max-w-2xl">
        {subtitle}
      </p>
    </div>
  );
}

/* ─── Text Input ─── */
export function TextInput({ label, placeholder, value, onChange, required, hint, type = 'text', icon }: {
  label: string;
  placeholder: string;
  value: string;
  onChange: (val: string) => void;
  required?: boolean;
  hint?: string;
  type?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <label className="flex items-center gap-2 text-sm font-medium text-text-secondary">
        {label}
        {required && <span className="text-pink-400 text-xs">*required</span>}
      </label>
      <div className="relative">
        {icon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted">
            {icon}
          </div>
        )}
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`w-full ${icon ? 'pl-11' : 'px-4'} pr-4 py-3.5 bg-dark-card border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 focus:ring-2 focus:ring-accent/10 transition-all duration-300`}
        />
      </div>
      {hint && (
        <p className="flex items-start gap-1.5 text-xs text-text-muted">
          <Info size={12} className="shrink-0 mt-0.5" />
          {hint}
        </p>
      )}
    </div>
  );
}

/* ─── URL Input (special styling) ─── */
export function UrlInput({ label, placeholder, value, onChange, required, hint }: {
  label: string;
  placeholder: string;
  value: string;
  onChange: (val: string) => void;
  required?: boolean;
  hint?: string;
}) {
  return (
    <div className="space-y-2">
      <label className="flex items-center gap-2 text-sm font-medium text-text-secondary">
        <LinkIcon size={14} className="text-accent" />
        {label}
        {required && <span className="text-pink-400 text-xs">*required</span>}
      </label>
      <input
        type="url"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-3.5 bg-dark-card border border-accent/20 rounded-xl text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 focus:ring-2 focus:ring-accent/10 transition-all duration-300"
      />
      {hint && (
        <p className="flex items-start gap-1.5 text-xs text-text-muted">
          <Info size={12} className="shrink-0 mt-0.5" />
          {hint}
        </p>
      )}
    </div>
  );
}

/* ─── Notion Link Input (special highlighted) ─── */
export function NotionLinkInput({ label, value, onChange, hint }: {
  label: string;
  value: string;
  onChange: (val: string) => void;
  hint?: string;
}) {
  return (
    <div className="space-y-3">
      <label className="flex items-center gap-2 text-sm font-semibold text-text-primary">
        <div className="w-6 h-6 rounded bg-white flex items-center justify-center">
          <span className="text-black font-bold text-xs">N</span>
        </div>
        {label}
      </label>
      <div className="relative">
        <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-accent/20 via-pink-500/20 to-blue-500/20 blur-sm" />
        <div className="relative bg-dark-card border-2 border-accent/30 rounded-xl p-1">
          <input
            type="url"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="https://www.notion.so/your-portfolio-page/..."
            className="w-full px-4 py-4 bg-dark border border-dark-border rounded-lg text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 transition-all duration-300 text-base"
          />
        </div>
      </div>
      {hint && (
        <div className="flex items-start gap-2 bg-accent/5 border border-accent/10 rounded-lg p-3">
          <Info size={14} className="text-accent shrink-0 mt-0.5" />
          <p className="text-xs text-text-secondary leading-relaxed">{hint}</p>
        </div>
      )}
    </div>
  );
}

/* ─── Textarea ─── */
export function TextArea({ label, placeholder, value, onChange, rows = 4, required, hint, maxLength }: {
  label: string;
  placeholder: string;
  value: string;
  onChange: (val: string) => void;
  rows?: number;
  required?: boolean;
  hint?: string;
  maxLength?: number;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="flex items-center gap-2 text-sm font-medium text-text-secondary">
          {label}
          {required && <span className="text-pink-400 text-xs">*required</span>}
        </label>
        {maxLength && (
          <span className={`text-xs ${value.length > maxLength ? 'text-pink-400' : 'text-text-muted'}`}>
            {value.length}/{maxLength}
          </span>
        )}
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="w-full px-4 py-3.5 bg-dark-card border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 focus:ring-2 focus:ring-accent/10 transition-all duration-300 resize-none"
      />
      {hint && (
        <p className="flex items-start gap-1.5 text-xs text-text-muted">
          <Info size={12} className="shrink-0 mt-0.5" />
          {hint}
        </p>
      )}
    </div>
  );
}

/* ─── Select Dropdown ─── */
export function SelectInput({ label, value, onChange, options, hint }: {
  label: string;
  value: string;
  onChange: (val: string) => void;
  options: { value: string; label: string }[];
  hint?: string;
}) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-text-secondary">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-3.5 bg-dark-card border border-dark-border rounded-xl text-text-primary focus:outline-none focus:border-accent/50 focus:ring-2 focus:ring-accent/10 transition-all duration-300 appearance-none cursor-pointer"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
      {hint && (
        <p className="flex items-start gap-1.5 text-xs text-text-muted">
          <Info size={12} className="shrink-0 mt-0.5" />
          {hint}
        </p>
      )}
    </div>
  );
}

/* ─── Color Picker ─── */
export function ColorInput({ label, value, onChange, hint }: {
  label: string;
  value: string;
  onChange: (val: string) => void;
  hint?: string;
}) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-text-secondary">{label}</label>
      <div className="flex items-center gap-3">
        <div className="relative">
          <input
            type="color"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-12 h-12 rounded-xl border border-dark-border cursor-pointer bg-transparent"
          />
        </div>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-4 py-3 bg-dark-card border border-dark-border rounded-xl text-text-primary font-mono text-sm focus:outline-none focus:border-accent/50 transition-all"
        />
      </div>
      {hint && (
        <p className="flex items-start gap-1.5 text-xs text-text-muted">
          <Info size={12} className="shrink-0 mt-0.5" />
          {hint}
        </p>
      )}
    </div>
  );
}

/* ─── Tag/Chip Input ─── */
export function TagInput({ label, tags, onChange, placeholder, hint }: {
  label: string;
  tags: string[];
  onChange: (tags: string[]) => void;
  placeholder: string;
  hint?: string;
}) {
  const [inputValue, setInputValue] = useState('');

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.key === 'Enter' || e.key === ',') && inputValue.trim()) {
      e.preventDefault();
      if (!tags.includes(inputValue.trim())) {
        onChange([...tags, inputValue.trim()]);
      }
      setInputValue('');
    }
    if (e.key === 'Backspace' && !inputValue && tags.length > 0) {
      onChange(tags.slice(0, -1));
    }
  };

  const removeTag = (index: number) => {
    onChange(tags.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-text-secondary">{label}</label>
      <div className="bg-dark-card border border-dark-border rounded-xl p-3 focus-within:border-accent/50 focus-within:ring-2 focus-within:ring-accent/10 transition-all duration-300">
        <div className="flex flex-wrap gap-2 mb-2">
          {tags.map((tag, index) => (
            <motion.span
              key={tag}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-accent/10 border border-accent/20 rounded-lg text-sm text-accent"
            >
              {tag}
              <button
                onClick={() => removeTag(index)}
                className="text-accent/60 hover:text-accent transition-colors"
              >
                <X size={12} />
              </button>
            </motion.span>
          ))}
        </div>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={tags.length === 0 ? placeholder : 'Add more...'}
          className="w-full bg-transparent text-text-primary placeholder:text-text-muted/50 focus:outline-none text-sm py-1"
        />
      </div>
      {hint && (
        <p className="flex items-start gap-1.5 text-xs text-text-muted">
          <Info size={12} className="shrink-0 mt-0.5" />
          {hint}
        </p>
      )}
    </div>
  );
}

/* ─── Star Rating ─── */
export function StarRating({ value, onChange }: {
  value: number;
  onChange: (val: number) => void;
}) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          onClick={() => onChange(star)}
          className="transition-transform hover:scale-110"
        >
          <Star
            size={20}
            className={star <= value ? 'fill-yellow-400 text-yellow-400' : 'text-dark-border'}
          />
        </button>
      ))}
    </div>
  );
}

/* ─── Toggle Switch ─── */
export function ToggleSwitch({ label, checked, onChange, hint }: {
  label: string;
  checked: boolean;
  onChange: (val: boolean) => void;
  hint?: string;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-text-secondary">{label}</label>
        <button
          onClick={() => onChange(!checked)}
          className={`relative w-12 h-6 rounded-full transition-colors duration-300 ${
            checked ? 'bg-accent' : 'bg-dark-border'
          }`}
        >
          <div
            className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-300 ${
              checked ? 'translate-x-6' : 'translate-x-0.5'
            }`}
          />
        </button>
      </div>
      {hint && (
        <p className="text-xs text-text-muted">{hint}</p>
      )}
    </div>
  );
}

/* ─── Repeatable Card Block ─── */
export function AddButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      className="w-full py-4 border-2 border-dashed border-dark-border rounded-xl text-text-muted hover:border-accent/40 hover:text-accent hover:bg-accent/5 transition-all duration-300 flex items-center justify-center gap-2 text-sm font-medium"
    >
      <Plus size={18} />
      {label}
    </motion.button>
  );
}

export function RemoveButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute top-3 right-3 w-8 h-8 rounded-lg bg-dark border border-dark-border flex items-center justify-center text-text-muted hover:text-pink-400 hover:border-pink-400/30 hover:bg-pink-400/5 transition-all duration-300 z-10"
    >
      <X size={14} />
    </button>
  );
}

/* ─── Subsection Divider ─── */
export function SubSection({ title, description, children }: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-1 h-6 rounded-full bg-gradient-to-b from-accent to-pink-500" />
        <div>
          <h3 className="text-lg font-semibold text-text-primary">{title}</h3>
          {description && <p className="text-sm text-text-muted">{description}</p>}
        </div>
      </div>
      <div className="pl-4 border-l border-dark-border/30 space-y-5">
        {children}
      </div>
    </div>
  );
}

/* ─── Info Banner ─── */
export function InfoBanner({ title, description, type = 'info' }: {
  title: string;
  description: string;
  type?: 'info' | 'tip' | 'notion';
}) {
  const styles = {
    info: 'bg-blue-500/5 border-blue-500/20 text-blue-400',
    tip: 'bg-green-500/5 border-green-500/20 text-green-400',
    notion: 'bg-white/5 border-white/20 text-white',
  };

  return (
    <div className={`rounded-xl border p-5 ${styles[type]}`}>
      <h4 className="font-semibold text-sm mb-1">{title}</h4>
      <p className="text-xs text-text-secondary leading-relaxed">{description}</p>
    </div>
  );
}
