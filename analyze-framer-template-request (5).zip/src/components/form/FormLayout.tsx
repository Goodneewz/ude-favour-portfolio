import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, Circle, ChevronRight } from 'lucide-react';

interface FormLayoutProps {
  currentStep: number;
  totalSteps: number;
  stepTitles: string[];
  children: React.ReactNode;
  onNext: () => void;
  onPrev: () => void;
  onSubmit: () => void;
  canProceed: boolean;
}

export function FormLayout({
  currentStep,
  totalSteps,
  stepTitles,
  children,
  onNext,
  onPrev,
  onSubmit,
  canProceed,
}: FormLayoutProps) {
  const progress = ((currentStep + 1) / totalSteps) * 100;

  return (
    <div className="min-h-screen bg-dark text-text-primary noise-bg relative">
      {/* Background orbs */}
      <div className="glow-orb w-[600px] h-[600px] bg-accent/10 top-[-15%] left-[-15%]" />
      <div className="glow-orb w-[500px] h-[500px] bg-pink-500/8 bottom-[-10%] right-[-10%]" style={{ animationDelay: '2s' }} />
      <div className="glow-orb w-[300px] h-[300px] bg-blue-500/5 top-[50%] left-[60%]" style={{ animationDelay: '1s' }} />

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-[0.02]" style={{
        backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
        backgroundSize: '60px 60px'
      }} />

      <div className="relative z-10 flex min-h-screen">
        {/* Sidebar - Step Navigation */}
        <aside className="hidden lg:flex flex-col w-80 xl:w-96 border-r border-dark-border/50 bg-dark-secondary/50 backdrop-blur-sm p-8 sticky top-0 h-screen overflow-y-auto">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-12">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-accent to-pink-500 flex items-center justify-center">
              <span className="text-white font-bold text-lg">P</span>
            </div>
            <div>
              <span className="text-text-primary font-semibold text-lg tracking-tight">
                Portfolio<span className="text-accent">.</span>Builder
              </span>
              <p className="text-xs text-text-muted">Landio-Inspired Template</p>
            </div>
          </div>

          {/* Steps */}
          <nav className="flex-1 space-y-1">
            {stepTitles.map((title, index) => {
              const isCompleted = index < currentStep;
              const isCurrent = index === currentStep;

              return (
                <div
                  key={index}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                    isCurrent
                      ? 'bg-accent/10 border border-accent/20'
                      : isCompleted
                      ? 'opacity-70 hover:opacity-90'
                      : 'opacity-40'
                  }`}
                >
                  <div className="shrink-0">
                    {isCompleted ? (
                      <CheckCircle size={20} className="text-green-400" />
                    ) : isCurrent ? (
                      <div className="w-5 h-5 rounded-full border-2 border-accent flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-accent" />
                      </div>
                    ) : (
                      <Circle size={20} className="text-text-muted" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${
                      isCurrent ? 'text-text-primary' : 'text-text-secondary'
                    }`}>
                      {title}
                    </p>
                    <p className="text-xs text-text-muted">Step {index + 1}</p>
                  </div>
                  {isCurrent && (
                    <ChevronRight size={16} className="text-accent shrink-0" />
                  )}
                </div>
              );
            })}
          </nav>

          {/* Progress */}
          <div className="pt-8 border-t border-dark-border/50 mt-8">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-text-muted">Progress</span>
              <span className="text-sm font-semibold text-accent">{Math.round(progress)}%</span>
            </div>
            <div className="w-full h-2 bg-dark-card rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-accent to-pink-500 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
              />
            </div>
            <p className="text-xs text-text-muted mt-2">
              {currentStep + 1} of {totalSteps} sections completed
            </p>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col">
          {/* Mobile Header */}
          <div className="lg:hidden sticky top-0 z-20 bg-dark/80 backdrop-blur-xl border-b border-dark-border/50 px-6 py-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-pink-500 flex items-center justify-center">
                  <span className="text-white font-bold text-sm">P</span>
                </div>
                <span className="text-text-primary font-semibold text-sm">
                  Portfolio<span className="text-accent">.</span>Builder
                </span>
              </div>
              <span className="text-xs text-text-muted font-medium bg-dark-card px-3 py-1 rounded-full">
                Step {currentStep + 1}/{totalSteps}
              </span>
            </div>
            <div className="w-full h-1.5 bg-dark-card rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-accent to-pink-500 rounded-full"
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          {/* Step Content */}
          <div className="flex-1 px-6 lg:px-12 xl:px-20 py-8 lg:py-12 max-w-4xl w-full mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.35, ease: 'easeOut' }}
                className="h-full"
              >
                {children}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Bottom Navigation */}
          <div className="sticky bottom-0 bg-dark/80 backdrop-blur-xl border-t border-dark-border/50 px-6 lg:px-12 xl:px-20 py-5">
            <div className="max-w-4xl mx-auto flex items-center justify-between">
              <button
                onClick={onPrev}
                disabled={currentStep === 0}
                className={`px-6 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                  currentStep === 0
                    ? 'opacity-30 cursor-not-allowed text-text-muted'
                    : 'border border-dark-border text-text-secondary hover:text-text-primary hover:border-text-muted hover:bg-white/5'
                }`}
              >
                ← Previous
              </button>

              <div className="hidden sm:flex items-center gap-1.5">
                {stepTitles.map((_, index) => (
                  <div
                    key={index}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      index === currentStep
                        ? 'w-8 bg-accent'
                        : index < currentStep
                        ? 'w-1.5 bg-accent/40'
                        : 'w-1.5 bg-dark-border'
                    }`}
                  />
                ))}
              </div>

              {currentStep === totalSteps - 1 ? (
                <motion.button
                  onClick={onSubmit}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-8 py-3 bg-gradient-to-r from-accent to-pink-500 text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-accent/25 transition-shadow"
                >
                  🚀 Generate Portfolio
                </motion.button>
              ) : (
                <motion.button
                  onClick={onNext}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={!canProceed}
                  className={`px-8 py-3 text-sm font-semibold rounded-xl transition-all duration-300 ${
                    canProceed
                      ? 'bg-gradient-to-r from-accent to-pink-500 text-white hover:shadow-lg hover:shadow-accent/25'
                      : 'bg-dark-card text-text-muted border border-dark-border cursor-not-allowed'
                  }`}
                >
                  Next Step →
                </motion.button>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
