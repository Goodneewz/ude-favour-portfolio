import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, ColorInput, SelectInput, ToggleSwitch, SubSection, InfoBanner } from '../FormInputs';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

const fontOptions = [
  { value: 'Inter', label: 'Inter (Clean, Modern)' },
  { value: 'Poppins', label: 'Poppins (Friendly, Rounded)' },
  { value: 'DM Sans', label: 'DM Sans (Geometric, Minimal)' },
  { value: 'Space Grotesk', label: 'Space Grotesk (Techy, Bold)' },
  { value: 'Outfit', label: 'Outfit (Contemporary)' },
  { value: 'Sora', label: 'Sora (Japanese-Inspired)' },
  { value: 'Manrope', label: 'Manrope (Elegant)' },
  { value: 'Plus Jakarta Sans', label: 'Plus Jakarta Sans (Professional)' },
  { value: 'Satoshi', label: 'Satoshi (Trendy, Modern)' },
  { value: 'General Sans', label: 'General Sans (Versatile)' },
];

const presetColors = [
  { name: 'Violet', primary: '#8b5cf6', secondary: '#ec4899' },
  { name: 'Blue', primary: '#3b82f6', secondary: '#06b6d4' },
  { name: 'Emerald', primary: '#10b981', secondary: '#06b6d4' },
  { name: 'Rose', primary: '#f43f5e', secondary: '#fb923c' },
  { name: 'Amber', primary: '#f59e0b', secondary: '#ef4444' },
  { name: 'Cyan', primary: '#06b6d4', secondary: '#8b5cf6' },
  { name: 'Indigo', primary: '#6366f1', secondary: '#ec4899' },
  { name: 'Lime', primary: '#84cc16', secondary: '#22d3ee' },
];

export function Step10Theme({ data, onChange }: Props) {
  return (
    <div className="space-y-10">
      <SectionTitle
        step={10}
        title="Theme &"
        highlight="Customization"
        subtitle="Make the portfolio truly yours. Choose your accent colors, font, and visual preferences. These settings affect the entire look and feel of your portfolio."
      />

      <SubSection title="Color Presets" description="Quick-pick a color scheme">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {presetColors.map((preset) => (
            <button
              key={preset.name}
              onClick={() => onChange({ accentColor: preset.primary, secondaryAccentColor: preset.secondary })}
              className={`relative p-4 rounded-xl border transition-all duration-300 text-center ${
                data.accentColor === preset.primary
                  ? 'border-accent bg-accent/10'
                  : 'border-dark-border hover:border-text-muted bg-dark-card'
              }`}
            >
              <div className="flex items-center justify-center gap-1 mb-2">
                <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.primary }} />
                <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.secondary }} />
              </div>
              <span className="text-xs font-medium text-text-secondary">{preset.name}</span>
              {data.accentColor === preset.primary && (
                <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-accent flex items-center justify-center">
                  <span className="text-white text-[8px]">✓</span>
                </div>
              )}
            </button>
          ))}
        </div>
      </SubSection>

      <SubSection title="Custom Colors" description="Fine-tune your exact colors">
        <div className="grid sm:grid-cols-2 gap-5">
          <ColorInput
            label="Primary Accent Color"
            value={data.accentColor}
            onChange={(val) => onChange({ accentColor: val })}
            hint="The main accent color used for buttons, highlights, links, and the gradient text. This is your brand's primary color."
          />
          <ColorInput
            label="Secondary Accent Color"
            value={data.secondaryAccentColor}
            onChange={(val) => onChange({ secondaryAccentColor: val })}
            hint="The secondary color used in gradients alongside the primary. Creates a gradient effect: Primary → Secondary."
          />
        </div>

        {/* Live gradient preview */}
        <div className="bg-dark-card border border-dark-border rounded-xl p-5 space-y-3">
          <p className="text-xs text-text-muted uppercase tracking-wider font-medium">Gradient Preview</p>
          <div
            className="h-12 rounded-lg"
            style={{ background: `linear-gradient(135deg, ${data.accentColor}, ${data.secondaryAccentColor})` }}
          />
          <div className="flex items-center gap-3">
            <div className="px-5 py-2 rounded-full text-white text-sm font-medium" style={{ background: `linear-gradient(135deg, ${data.accentColor}, ${data.secondaryAccentColor})` }}>
              Button Preview
            </div>
            <span
              className="text-2xl font-bold"
              style={{
                background: `linear-gradient(135deg, ${data.accentColor}, ${data.secondaryAccentColor})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Gradient Text
            </span>
          </div>
        </div>
      </SubSection>

      <SubSection title="Typography" description="Choose the font for your portfolio">
        <SelectInput
          label="Font Family"
          value={data.fontFamily}
          onChange={(val) => onChange({ fontFamily: val })}
          options={fontOptions}
          hint="The font used throughout your entire portfolio. Each font has a different personality — choose one that matches your brand."
        />

        <InfoBanner
          type="info"
          title="🔤 Font previews"
          description="Inter: Clean and professional, great for developers. Poppins: Friendly and approachable. Space Grotesk: Bold and techy. DM Sans: Minimal and geometric. Plus Jakarta Sans: Polished and corporate-friendly."
        />
      </SubSection>

      <SubSection title="Display Mode" description="Light or dark mode">
        <ToggleSwitch
          label="Dark Mode (Recommended for Landio style)"
          checked={data.darkMode}
          onChange={(val) => onChange({ darkMode: val })}
          hint="The Landio template is designed for dark mode. Dark mode is recommended for the best visual experience, but you can toggle this if you prefer a light background."
        />
      </SubSection>
    </div>
  );
}
