import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, UrlInput, SubSection, InfoBanner } from '../FormInputs';
import { User, Fingerprint } from 'lucide-react';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

export function Step1Identity({ data, onChange }: Props) {
  return (
    <div className="space-y-10">
      <SectionTitle
        step={1}
        title="Identity &"
        highlight="Branding"
        subtitle="Let's start with who you are. This information shapes the entire identity of your portfolio — your name, your brand, and how visitors first perceive you."
      />

      <InfoBanner
        type="tip"
        title="💡 Pro tip"
        description="Your brand name could be your real name (e.g., 'John.dev'), a creative alias, or your studio/agency name. The logo initials appear inside the circular logo mark in the navbar."
      />

      <SubSection title="Personal Information" description="Your real name and how you'd like to be known">
        <TextInput
          label="Full Name"
          placeholder="e.g., John Doe, Jane Smith, Alex Chen"
          value={data.fullName}
          onChange={(val) => onChange({ fullName: val })}
          required
          hint="Your full legal name or the name you go by professionally."
          icon={<User size={16} />}
        />

        <TextInput
          label="Brand Name"
          placeholder="e.g., john.dev, JaneDesigns, AlexStudio"
          value={data.brandName}
          onChange={(val) => onChange({ brandName: val })}
          required
          hint="This appears in the navbar logo area. Include a dot for style (e.g., 'name.dev') or keep it simple."
          icon={<Fingerprint size={16} />}
        />

        <TextInput
          label="Logo Initials"
          placeholder="e.g., JD, A, JS"
          value={data.logoInitials}
          onChange={(val) => onChange({ logoInitials: val.slice(0, 3) })}
          required
          hint="1-3 characters that appear inside the gradient logo circle. Usually your first name initial or first+last initials."
        />

        <TextInput
          label="Short Tagline / Title"
          placeholder="e.g., Creative Developer, UI/UX Designer, Full-Stack Engineer"
          value={data.tagline}
          onChange={(val) => onChange({ tagline: val })}
          hint="A brief title or tagline that describes what you do. Used in meta tags and as a quick descriptor."
        />
      </SubSection>

      <SubSection title="Profile Photo" description="A photo or avatar that represents you visually">
        <UrlInput
          label="Profile Photo URL"
          placeholder="https://example.com/your-photo.jpg"
          value={data.profilePhotoUrl}
          onChange={(val) => onChange({ profilePhotoUrl: val })}
          hint="Paste a direct link to your profile photo. You can use services like Imgur, Cloudinary, or your own hosted image. Recommended size: 400x400px or larger, square crop."
        />

        {data.profilePhotoUrl && (
          <div className="flex items-center gap-4 p-4 bg-dark border border-dark-border rounded-xl">
            <img
              src={data.profilePhotoUrl}
              alt="Profile preview"
              className="w-16 h-16 rounded-xl object-cover border border-dark-border"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
            <div>
              <p className="text-sm text-text-primary font-medium">Preview</p>
              <p className="text-xs text-text-muted">If the image doesn't load, check the URL</p>
            </div>
          </div>
        )}
      </SubSection>

      <SubSection title="Resume / CV" description="Optional: Link to your downloadable resume">
        <UrlInput
          label="Resume / CV URL"
          placeholder="https://drive.google.com/your-resume.pdf"
          value={data.resumeUrl}
          onChange={(val) => onChange({ resumeUrl: val })}
          hint="Link to a PDF of your resume/CV. Can be hosted on Google Drive, Dropbox, or your own server. This will appear as a downloadable link on the portfolio."
        />
      </SubSection>
    </div>
  );
}
