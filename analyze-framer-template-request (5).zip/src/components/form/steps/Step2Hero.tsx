import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, TextArea, SelectInput, SubSection, InfoBanner } from '../FormInputs';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

export function Step2Hero({ data, onChange }: Props) {
  const updateStat = (index: number, field: 'number' | 'label', value: string) => {
    const newStats = [...data.stats];
    newStats[index] = { ...newStats[index], [field]: value };
    onChange({ stats: newStats });
  };

  return (
    <div className="space-y-10">
      <SectionTitle
        step={2}
        title="Hero"
        highlight="Section"
        subtitle="The hero is the very first thing visitors see — the big, bold opening of your portfolio. This is where you make a powerful first impression with your headline, subtitle, and key stats."
      />

      <InfoBanner
        type="info"
        title="🎯 How it works"
        description="The headline is split into 3 lines for dramatic typographic effect. Line 1 and Line 3 use regular white text, while Line 2 uses the gradient accent color. You can also leave any line blank if you want a shorter headline."
      />

      <SubSection title="Headline" description="Your bold, attention-grabbing hero text (up to 3 lines)">
        <TextInput
          label="Headline — Line 1"
          placeholder="e.g., I craft, I build, Hello I'm"
          value={data.heroHeadlineLine1}
          onChange={(val) => onChange({ heroHeadlineLine1: val })}
          required
          hint="First line of your hero heading. Appears in white text."
        />
        <TextInput
          label="Headline — Line 2 (Gradient Highlight)"
          placeholder="e.g., digital experiences, amazing products, John Doe"
          value={data.heroHeadlineLine2}
          onChange={(val) => onChange({ heroHeadlineLine2: val })}
          required
          hint="This line gets the gradient color treatment — it's the visual highlight of your headline."
        />
        <TextInput
          label="Headline — Line 3"
          placeholder="e.g., that inspire., from scratch., a developer."
          value={data.heroHeadlineLine3}
          onChange={(val) => onChange({ heroHeadlineLine3: val })}
          hint="Final line of your headline. Can include a period for emphasis. Leave blank if you prefer just 2 lines."
        />
      </SubSection>

      <SubSection title="Subtitle" description="A supporting paragraph below the headline">
        <TextArea
          label="Hero Subtitle / Description"
          placeholder="e.g., A creative developer & designer specializing in building beautiful, performant web applications that solve real problems and delight users."
          value={data.heroSubtitle}
          onChange={(val) => onChange({ heroSubtitle: val })}
          rows={3}
          required
          hint="1-3 sentences that expand on your headline. Explain what you do, who you help, and what makes you different."
          maxLength={300}
        />
      </SubSection>

      <SubSection title="Availability Badge" description="The small badge above your headline">
        <SelectInput
          label="Availability Status"
          value={data.availabilityStatus}
          onChange={(val) => onChange({ availabilityStatus: val })}
          options={[
            { value: 'available', label: '🟢 Available' },
            { value: 'busy', label: '🟡 Limited Availability' },
            { value: 'unavailable', label: '🔴 Not Available' },
            { value: 'custom', label: '✏️ Custom Text' },
          ]}
          hint="Shows as a small badge above your hero headline."
        />
        <TextInput
          label="Badge Text"
          placeholder="e.g., Available for freelance work, Open to new opportunities"
          value={data.availabilityText}
          onChange={(val) => onChange({ availabilityText: val })}
          hint="The text that appears inside the availability badge."
        />
      </SubSection>

      <SubSection title="Call-to-Action Buttons" description="The two buttons below your subtitle">
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Primary Button Text"
            placeholder="e.g., View My Work"
            value={data.primaryCtaText}
            onChange={(val) => onChange({ primaryCtaText: val })}
            hint="The main gradient-colored button."
          />
          <TextInput
            label="Primary Button Link"
            placeholder="e.g., #work, https://..."
            value={data.primaryCtaLink}
            onChange={(val) => onChange({ primaryCtaLink: val })}
            hint="Where the button links to. Use #section-id for page sections."
          />
        </div>
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Secondary Button Text"
            placeholder="e.g., Learn More, About Me"
            value={data.secondaryCtaText}
            onChange={(val) => onChange({ secondaryCtaText: val })}
            hint="The outline-style button."
          />
          <TextInput
            label="Secondary Button Link"
            placeholder="e.g., #about, https://..."
            value={data.secondaryCtaLink}
            onChange={(val) => onChange({ secondaryCtaLink: val })}
          />
        </div>
      </SubSection>

      <SubSection title="Stats / Numbers" description="Key achievements displayed below the hero">
        <InfoBanner
          type="tip"
          title="📊 Stats that impress"
          description="These are the big numbers visitors see right away — things like '50+ Projects', '5+ Years Experience', '30+ Happy Clients'. Keep labels short and numbers impactful. You can have up to 4 stats."
        />

        <div className="space-y-4">
          {data.stats.map((stat, index) => (
            <div key={index} className="flex items-center gap-4 p-4 bg-dark border border-dark-border rounded-xl">
              <span className="text-xs text-text-muted font-mono w-8 shrink-0">#{index + 1}</span>
              <div className="flex-1 grid sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  value={stat.number}
                  onChange={(e) => updateStat(index, 'number', e.target.value)}
                  placeholder="e.g., 50+, 99%, 5+"
                  className="w-full px-3 py-2.5 bg-dark-card border border-dark-border rounded-lg text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 transition-all text-sm"
                />
                <input
                  type="text"
                  value={stat.label}
                  onChange={(e) => updateStat(index, 'label', e.target.value)}
                  placeholder="e.g., Projects Delivered"
                  className="w-full px-3 py-2.5 bg-dark-card border border-dark-border rounded-lg text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 transition-all text-sm"
                />
              </div>
            </div>
          ))}
        </div>
      </SubSection>
    </div>
  );
}
