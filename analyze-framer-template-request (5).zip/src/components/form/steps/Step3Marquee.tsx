import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TagInput, SubSection, InfoBanner } from '../FormInputs';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

export function Step3Marquee({ data, onChange }: Props) {
  return (
    <div className="space-y-10">
      <SectionTitle
        step={3}
        title="Scrolling"
        highlight="Ticker"
        subtitle="The marquee is an infinite-scrolling horizontal ticker that runs between the hero and about sections. It shows your key skills, technologies, or expertise areas in a visually engaging way."
      />

      <InfoBanner
        type="info"
        title="🎬 How the ticker works"
        description="Items scroll continuously from right to left, separated by ✦ diamond symbols. Add as many items as you want — the more you add, the richer the ticker looks. Common items include technologies, skills, tools, and areas of expertise."
      />

      <SubSection title="Ticker Items" description="Skills, tools, and technologies that scroll across the screen">
        <TagInput
          label="Add items to the scrolling ticker"
          tags={data.marqueeItems}
          onChange={(tags) => onChange({ marqueeItems: tags })}
          placeholder="Type a skill or technology and press Enter (e.g., React, UI/UX Design, TypeScript...)"
          hint="Press Enter or comma to add each item. Press Backspace to remove the last item. Items will scroll infinitely across the screen in the final portfolio."
        />

        {data.marqueeItems.length > 0 && (
          <div className="bg-dark-card border border-dark-border rounded-xl p-5">
            <p className="text-xs text-text-muted mb-3 uppercase tracking-wider font-medium">Preview (how it'll look):</p>
            <div className="flex items-center gap-3 flex-wrap">
              {data.marqueeItems.map((item, i) => (
                <span key={i} className="flex items-center gap-3">
                  <span className="text-base font-medium text-text-secondary">{item}</span>
                  {i < data.marqueeItems.length - 1 && (
                    <span className="text-accent text-xs">✦</span>
                  )}
                </span>
              ))}
            </div>
          </div>
        )}

        <InfoBanner
          type="tip"
          title="💡 Suggestions"
          description="Common ticker items: Web Development, UI/UX Design, React, TypeScript, Next.js, Tailwind CSS, Figma, Node.js, Python, Mobile Development, Branding, Performance Optimization, API Design, DevOps, Cloud Architecture, etc."
        />
      </SubSection>
    </div>
  );
}
