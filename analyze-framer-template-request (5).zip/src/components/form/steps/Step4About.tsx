import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, TextArea, SelectInput, TagInput, SubSection, InfoBanner } from '../FormInputs';
import { MapPin, Clock } from 'lucide-react';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

const iconOptions = [
  { value: 'code', label: '💻 Code / Development' },
  { value: 'palette', label: '🎨 Palette / Design' },
  { value: 'zap', label: '⚡ Zap / Performance' },
  { value: 'globe', label: '🌍 Globe / Full Stack' },
  { value: 'smartphone', label: '📱 Smartphone / Mobile' },
  { value: 'layers', label: '📐 Layers / Architecture' },
  { value: 'database', label: '🗄️ Database / Backend' },
  { value: 'brain', label: '🧠 Brain / AI/ML' },
  { value: 'shield', label: '🛡️ Shield / Security' },
  { value: 'rocket', label: '🚀 Rocket / Startup' },
  { value: 'camera', label: '📷 Camera / Media' },
  { value: 'pen-tool', label: '✏️ Pen / Creative' },
];

export function Step4About({ data, onChange }: Props) {
  const updateSkillCard = (index: number, field: string, value: string) => {
    const newCards = [...data.skillCards];
    newCards[index] = { ...newCards[index], [field]: value };
    onChange({ skillCards: newCards });
  };

  const addSkillCard = () => {
    onChange({
      skillCards: [...data.skillCards, { iconType: 'code', title: '', description: '' }],
    });
  };

  const removeSkillCard = (index: number) => {
    if (data.skillCards.length > 1) {
      onChange({ skillCards: data.skillCards.filter((_, i) => i !== index) });
    }
  };

  return (
    <div className="space-y-10">
      <SectionTitle
        step={4}
        title="About"
        highlight="You"
        subtitle="This is where visitors learn your story. Write about your background, experience, passions, and what drives you. Be authentic — people connect with real stories, not corporate speak."
      />

      <SubSection title="Section Heading" description="Customize the heading for your About section">
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Heading Text"
            placeholder="e.g., Passionate about creating"
            value={data.aboutHeading}
            onChange={(val) => onChange({ aboutHeading: val })}
            hint="The non-highlighted part of the section heading."
          />
          <TextInput
            label="Heading Highlight (Gradient)"
            placeholder="e.g., meaningful experiences"
            value={data.aboutHeadingHighlight}
            onChange={(val) => onChange({ aboutHeadingHighlight: val })}
            hint="This part gets the gradient color — make it impactful."
          />
        </div>
      </SubSection>

      <SubSection title="Your Story" description="Tell visitors about yourself in your own words">
        <TextArea
          label="Bio — Paragraph 1 (Introduction)"
          placeholder="e.g., Hi, I'm [Your Name] — a creative developer based in [Location]. With over [X] years of experience, I bridge the gap between design and development to create products that are not only visually stunning but also highly functional and performant."
          value={data.aboutParagraph1}
          onChange={(val) => onChange({ aboutParagraph1: val })}
          rows={4}
          required
          hint="Start by introducing yourself — your name, what you do, where you're based, and a quick overview of your experience."
          maxLength={500}
        />

        <TextArea
          label="Bio — Paragraph 2 (Philosophy & Approach)"
          placeholder="e.g., I believe in the power of clean code and thoughtful design. Every project I take on is an opportunity to push boundaries and deliver something exceptional."
          value={data.aboutParagraph2}
          onChange={(val) => onChange({ aboutParagraph2: val })}
          rows={4}
          hint="Share your work philosophy, approach to projects, or what makes you unique. What do you care about? What's your design/development philosophy?"
          maxLength={500}
        />

        <TextArea
          label="Bio — Paragraph 3 (Additional Info, Optional)"
          placeholder="e.g., When I'm not coding, you can find me exploring new technologies, contributing to open-source projects, or mentoring aspiring developers in my community."
          value={data.aboutParagraph3}
          onChange={(val) => onChange({ aboutParagraph3: val })}
          rows={3}
          hint="Optional: Add personal interests, hobbies, community involvement, or anything else that makes you human and relatable."
          maxLength={400}
        />
      </SubSection>

      <SubSection title="Location & Experience" description="Quick facts about you">
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Location"
            placeholder="e.g., San Francisco, CA | Lagos, Nigeria | London, UK"
            value={data.location}
            onChange={(val) => onChange({ location: val })}
            hint="Your city and country/state. This appears in the About section and Contact section."
            icon={<MapPin size={16} />}
          />
          <TextInput
            label="Years of Experience"
            placeholder="e.g., 5+, 3, 10+"
            value={data.yearsExperience}
            onChange={(val) => onChange({ yearsExperience: val })}
            hint="How long you've been working professionally in your field."
            icon={<Clock size={16} />}
          />
        </div>
      </SubSection>

      <SubSection title="Tech Stack" description="All the technologies and tools you work with">
        <TagInput
          label="Technologies & Tools"
          tags={data.techStack}
          onChange={(tags) => onChange({ techStack: tags })}
          placeholder="Type a technology and press Enter (e.g., React, Figma, Node.js...)"
          hint="These appear as interactive pills/chips in your About section. Add all the tools, languages, frameworks, and platforms you're proficient in."
        />
      </SubSection>

      <SubSection title="Skill Cards" description="4 cards highlighting your key competency areas">
        <InfoBanner
          type="info"
          title="📋 Skill cards"
          description="These are the 4 cards displayed in a 2×2 grid next to your bio. Each card has an icon, a title, and a short description. They represent your primary areas of expertise."
        />

        <div className="space-y-4">
          {data.skillCards.map((card, index) => (
            <div key={index} className="relative bg-dark border border-dark-border rounded-xl p-5 space-y-4">
              {data.skillCards.length > 1 && (
                <button
                  onClick={() => removeSkillCard(index)}
                  className="absolute top-3 right-3 w-7 h-7 rounded-lg bg-dark-card border border-dark-border flex items-center justify-center text-text-muted hover:text-pink-400 hover:border-pink-400/30 transition-all text-xs"
                >
                  ✕
                </button>
              )}

              <div className="flex items-center gap-2 text-xs text-text-muted font-mono">
                <span className="px-2 py-0.5 bg-accent/10 text-accent rounded">Card #{index + 1}</span>
              </div>

              <SelectInput
                label="Icon"
                value={card.iconType}
                onChange={(val) => updateSkillCard(index, 'iconType', val)}
                options={iconOptions}
              />

              <TextInput
                label="Card Title"
                placeholder="e.g., Frontend Development, UI/UX Design"
                value={card.title}
                onChange={(val) => updateSkillCard(index, 'title', val)}
              />

              <TextInput
                label="Card Description"
                placeholder="e.g., React, Next.js, TypeScript"
                value={card.description}
                onChange={(val) => updateSkillCard(index, 'description', val)}
                hint="A short 3-5 word description or list of related technologies."
              />
            </div>
          ))}
        </div>

        {data.skillCards.length < 8 && (
          <button
            onClick={addSkillCard}
            className="w-full py-3 border-2 border-dashed border-dark-border rounded-xl text-text-muted hover:border-accent/40 hover:text-accent hover:bg-accent/5 transition-all text-sm font-medium"
          >
            + Add Another Skill Card
          </button>
        )}
      </SubSection>
    </div>
  );
}
