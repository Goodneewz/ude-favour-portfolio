import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, TextArea, SelectInput, SubSection, InfoBanner } from '../FormInputs';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

const iconOptions = [
  { value: 'monitor', label: '🖥️ Monitor / Web Dev' },
  { value: 'smartphone', label: '📱 Smartphone / Mobile' },
  { value: 'layers', label: '📐 Layers / UI Design' },
  { value: 'trending-up', label: '📈 Trending / Growth' },
  { value: 'code', label: '💻 Code / Development' },
  { value: 'palette', label: '🎨 Palette / Design' },
  { value: 'zap', label: '⚡ Zap / Performance' },
  { value: 'globe', label: '🌍 Globe / International' },
  { value: 'database', label: '🗄️ Database / Backend' },
  { value: 'shield', label: '🛡️ Shield / Security' },
  { value: 'search', label: '🔍 Search / SEO' },
  { value: 'megaphone', label: '📢 Megaphone / Marketing' },
  { value: 'pen-tool', label: '✏️ Pen / Branding' },
  { value: 'video', label: '🎬 Video / Media' },
  { value: 'bot', label: '🤖 Bot / AI' },
  { value: 'cloud', label: '☁️ Cloud / DevOps' },
];

export function Step5Services({ data, onChange }: Props) {
  const updateService = (index: number, field: string, value: string | string[]) => {
    const newServices = [...data.services];
    newServices[index] = { ...newServices[index], [field]: value };
    onChange({ services: newServices });
  };

  const updateServiceFeature = (serviceIndex: number, featureIndex: number, value: string) => {
    const newServices = [...data.services];
    const newFeatures = [...newServices[serviceIndex].features];
    newFeatures[featureIndex] = value;
    newServices[serviceIndex] = { ...newServices[serviceIndex], features: newFeatures };
    onChange({ services: newServices });
  };

  const addService = () => {
    onChange({
      services: [...data.services, { iconType: 'code', title: '', description: '', features: ['', '', '', ''] }],
    });
  };

  const removeService = (index: number) => {
    if (data.services.length > 1) {
      onChange({ services: data.services.filter((_, i) => i !== index) });
    }
  };

  const addFeatureToService = (serviceIndex: number) => {
    const newServices = [...data.services];
    newServices[serviceIndex] = {
      ...newServices[serviceIndex],
      features: [...newServices[serviceIndex].features, ''],
    };
    onChange({ services: newServices });
  };

  const removeFeatureFromService = (serviceIndex: number, featureIndex: number) => {
    const newServices = [...data.services];
    newServices[serviceIndex] = {
      ...newServices[serviceIndex],
      features: newServices[serviceIndex].features.filter((_, i) => i !== featureIndex),
    };
    onChange({ services: newServices });
  };

  return (
    <div className="space-y-10">
      <SectionTitle
        step={5}
        title="Your"
        highlight="Services"
        subtitle="What do you offer? Define the services you provide so potential clients or employers understand exactly how you can help them. Each service gets its own card with a title, description, icon, and feature tags."
      />

      <SubSection title="Section Heading" description="Customize the heading for your Services section">
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Heading Text"
            placeholder="e.g., What I"
            value={data.servicesHeading}
            onChange={(val) => onChange({ servicesHeading: val })}
          />
          <TextInput
            label="Heading Highlight (Gradient)"
            placeholder="e.g., do best"
            value={data.servicesHeadingHighlight}
            onChange={(val) => onChange({ servicesHeadingHighlight: val })}
          />
        </div>

        <TextArea
          label="Services Section Subtitle"
          placeholder="e.g., I offer a comprehensive range of services to help bring your digital vision to life."
          value={data.servicesSubtitle}
          onChange={(val) => onChange({ servicesSubtitle: val })}
          rows={2}
          hint="A brief sentence describing your services overall."
          maxLength={200}
        />
      </SubSection>

      <SubSection title="Service Cards" description="Define each service you offer">
        <InfoBanner
          type="info"
          title="📋 Service card structure"
          description="Each service card includes: an icon, a title, a description paragraph, and up to 6 feature tags (small labels like 'Single Page Apps', 'User Research', etc.). The template displays them in a 2-column grid."
        />

        <div className="space-y-6">
          {data.services.map((service, sIndex) => (
            <div key={sIndex} className="relative bg-dark border border-dark-border rounded-2xl p-6 space-y-5">
              {data.services.length > 1 && (
                <button
                  onClick={() => removeService(sIndex)}
                  className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-dark-card border border-dark-border flex items-center justify-center text-text-muted hover:text-pink-400 hover:border-pink-400/30 transition-all text-xs"
                >
                  ✕
                </button>
              )}

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-accent/10 text-accent rounded-lg text-xs font-semibold">
                  Service #{sIndex + 1}
                </span>
              </div>

              <SelectInput
                label="Service Icon"
                value={service.iconType}
                onChange={(val) => updateService(sIndex, 'iconType', val)}
                options={iconOptions}
              />

              <TextInput
                label="Service Title"
                placeholder="e.g., Web Development, UI/UX Design, Mobile Apps"
                value={service.title}
                onChange={(val) => updateService(sIndex, 'title', val)}
                required
              />

              <TextArea
                label="Service Description"
                placeholder="e.g., Building responsive, fast, and scalable web applications using modern technologies like React, Next.js, and TypeScript."
                value={service.description}
                onChange={(val) => updateService(sIndex, 'description', val)}
                rows={3}
                hint="2-3 sentences explaining what this service includes and the value you provide."
                maxLength={300}
              />

              <div className="space-y-3">
                <label className="block text-sm font-medium text-text-secondary">
                  Feature Tags
                  <span className="text-text-muted text-xs ml-2">(small labels shown on the card)</span>
                </label>
                <div className="space-y-2">
                  {service.features.map((feature, fIndex) => (
                    <div key={fIndex} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={feature}
                        onChange={(e) => updateServiceFeature(sIndex, fIndex, e.target.value)}
                        placeholder={`Feature ${fIndex + 1}, e.g., Single Page Apps, User Research...`}
                        className="flex-1 px-3 py-2.5 bg-dark-card border border-dark-border rounded-lg text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 transition-all text-sm"
                      />
                      {service.features.length > 1 && (
                        <button
                          onClick={() => removeFeatureFromService(sIndex, fIndex)}
                          className="w-8 h-8 rounded-lg border border-dark-border flex items-center justify-center text-text-muted hover:text-pink-400 hover:border-pink-400/30 transition-all text-xs shrink-0"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                {service.features.length < 6 && (
                  <button
                    onClick={() => addFeatureToService(sIndex)}
                    className="text-xs text-accent hover:text-accent-light transition-colors font-medium"
                  >
                    + Add feature tag
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {data.services.length < 8 && (
          <button
            onClick={addService}
            className="w-full py-4 border-2 border-dashed border-dark-border rounded-xl text-text-muted hover:border-accent/40 hover:text-accent hover:bg-accent/5 transition-all text-sm font-medium"
          >
            + Add Another Service
          </button>
        )}
      </SubSection>
    </div>
  );
}
