import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, TextArea, UrlInput, TagInput, NotionLinkInput, ToggleSwitch, SelectInput, SubSection, InfoBanner } from '../FormInputs';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

const gradientOptions = [
  { value: 'from-violet-500 to-purple-600', label: '💜 Violet → Purple' },
  { value: 'from-pink-500 to-rose-600', label: '💗 Pink → Rose' },
  { value: 'from-blue-500 to-cyan-600', label: '💙 Blue → Cyan' },
  { value: 'from-green-500 to-emerald-600', label: '💚 Green → Emerald' },
  { value: 'from-yellow-500 to-orange-500', label: '💛 Yellow → Orange' },
  { value: 'from-red-500 to-pink-500', label: '❤️ Red → Pink' },
  { value: 'from-indigo-500 to-blue-600', label: '🔵 Indigo → Blue' },
  { value: 'from-teal-500 to-green-500', label: '🌊 Teal → Green' },
  { value: 'from-amber-500 to-red-500', label: '🔥 Amber → Red' },
  { value: 'from-fuchsia-500 to-purple-600', label: '🌸 Fuchsia → Purple' },
];

export function Step6Work({ data, onChange }: Props) {
  const updateProject = (index: number, field: string, value: string | string[] | boolean) => {
    const newProjects = [...data.projects];
    newProjects[index] = { ...newProjects[index], [field]: value };
    onChange({ projects: newProjects });
  };

  const addProject = () => {
    const colors = gradientOptions.map(g => g.value);
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    onChange({
      projects: [...data.projects, {
        title: '', category: '', description: '', tags: [],
        liveUrl: '', githubUrl: '', imageUrl: '',
        gradientColor: randomColor, featured: false,
      }],
    });
  };

  const removeProject = (index: number) => {
    if (data.projects.length > 1) {
      onChange({ projects: data.projects.filter((_, i) => i !== index) });
    }
  };

  return (
    <div className="space-y-10">
      <SectionTitle
        step={6}
        title="Portfolio &"
        highlight="Projects"
        subtitle="Showcase your best work. This is what potential clients and employers look at most carefully. Add your projects manually below, or paste a Notion link containing your portfolio details and I'll pull the content from there."
      />

      {/* NOTION LINK — THE STAR OF THE SHOW */}
      <div className="space-y-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center">
            <span className="text-black font-bold text-sm">N</span>
          </div>
          <div>
            <h3 className="text-lg font-bold text-text-primary">Import from Notion</h3>
            <p className="text-sm text-text-muted">Paste a link to your Notion page with your portfolio/proof of work</p>
          </div>
        </div>

        <NotionLinkInput
          label="Notion Portfolio / Proof of Work Link"
          value={data.notionPortfolioLink}
          onChange={(val) => onChange({ notionPortfolioLink: val })}
          hint="Paste the full URL to your Notion page that contains your portfolio, case studies, or proof of work. Make sure the page is shared publicly (Share → 'Publish to web' or 'Anyone with the link'). The content from this page will be analyzed and used to populate your project cards, descriptions, and details. Supported formats: notion.so links, notion.site links."
        />

        <InfoBanner
          type="notion"
          title="📝 What your Notion page should contain"
          description="For best results, structure your Notion page with: project titles, descriptions, technologies used, links to live sites and GitHub repos, client names, screenshots/images, and any case study details. The more detailed your Notion page, the better your portfolio will look."
        />
      </div>

      <div className="flex items-center gap-4 py-4">
        <div className="flex-1 h-px bg-dark-border" />
        <span className="text-xs text-text-muted font-medium uppercase tracking-wider">Or add projects manually</span>
        <div className="flex-1 h-px bg-dark-border" />
      </div>

      <SubSection title="Section Heading" description="Customize the heading for your Work section">
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Heading Text"
            placeholder="e.g., Selected"
            value={data.workHeading}
            onChange={(val) => onChange({ workHeading: val })}
          />
          <TextInput
            label="Heading Highlight (Gradient)"
            placeholder="e.g., works"
            value={data.workHeadingHighlight}
            onChange={(val) => onChange({ workHeadingHighlight: val })}
          />
        </div>
        <TextArea
          label="Portfolio Section Subtitle"
          placeholder="e.g., A curated selection of projects that showcase my expertise in design and development."
          value={data.workSubtitle}
          onChange={(val) => onChange({ workSubtitle: val })}
          rows={2}
          maxLength={200}
        />
      </SubSection>

      <SubSection title="Projects" description="Add each project with its details">
        <InfoBanner
          type="tip"
          title="⭐ Featured vs Regular"
          description="Featured projects get larger cards with image previews and appear at the top. Regular projects appear in a smaller grid below. Mark your 1-2 best projects as featured."
        />

        <div className="space-y-6">
          {data.projects.map((project, pIndex) => (
            <div key={pIndex} className={`relative border rounded-2xl p-6 space-y-5 ${
              project.featured 
                ? 'bg-accent/5 border-accent/20' 
                : 'bg-dark border-dark-border'
            }`}>
              {data.projects.length > 1 && (
                <button
                  onClick={() => removeProject(pIndex)}
                  className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-dark-card border border-dark-border flex items-center justify-center text-text-muted hover:text-pink-400 hover:border-pink-400/30 transition-all text-xs"
                >
                  ✕
                </button>
              )}

              <div className="flex items-center gap-2 flex-wrap">
                <span className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                  project.featured 
                    ? 'bg-accent/20 text-accent' 
                    : 'bg-dark-card text-text-muted border border-dark-border'
                }`}>
                  Project #{pIndex + 1}
                </span>
                {project.featured && (
                  <span className="px-2 py-0.5 bg-yellow-500/10 text-yellow-400 rounded text-xs font-medium">
                    ⭐ Featured
                  </span>
                )}
              </div>

              <ToggleSwitch
                label="Featured Project (larger card with image)"
                checked={project.featured}
                onChange={(val) => updateProject(pIndex, 'featured', val)}
                hint="Featured projects appear at the top with bigger cards and image previews."
              />

              <TextInput
                label="Project Title"
                placeholder="e.g., Lumina Dashboard, E-Commerce Platform"
                value={project.title}
                onChange={(val) => updateProject(pIndex, 'title', val)}
                required
              />

              <TextInput
                label="Project Category"
                placeholder="e.g., Web Application, Mobile App, Design System, E-Commerce"
                value={project.category}
                onChange={(val) => updateProject(pIndex, 'category', val)}
              />

              <TextArea
                label="Project Description"
                placeholder="e.g., A comprehensive analytics dashboard with real-time data visualization, dark mode, and responsive design for SaaS platforms."
                value={project.description}
                onChange={(val) => updateProject(pIndex, 'description', val)}
                rows={3}
                hint="2-3 sentences about what the project is, its key features, and the technologies/approach used."
                maxLength={300}
              />

              <TagInput
                label="Technology Tags"
                tags={project.tags}
                onChange={(tags) => updateProject(pIndex, 'tags', tags)}
                placeholder="Type a technology and press Enter (e.g., React, TypeScript...)"
                hint="Technologies and tools used in this project. These appear as small labels on the project card."
              />

              <div className="grid sm:grid-cols-2 gap-5">
                <UrlInput
                  label="Live Site URL"
                  placeholder="https://myproject.com"
                  value={project.liveUrl}
                  onChange={(val) => updateProject(pIndex, 'liveUrl', val)}
                  hint="Link to the deployed/live version of the project."
                />
                <UrlInput
                  label="GitHub Repository URL"
                  placeholder="https://github.com/user/repo"
                  value={project.githubUrl}
                  onChange={(val) => updateProject(pIndex, 'githubUrl', val)}
                  hint="Link to the source code repository."
                />
              </div>

              <UrlInput
                label="Project Screenshot / Image URL"
                placeholder="https://example.com/screenshot.png"
                value={project.imageUrl}
                onChange={(val) => updateProject(pIndex, 'imageUrl', val)}
                hint="A screenshot or preview image of the project. If left empty, a gradient placeholder will be used."
              />

              <SelectInput
                label="Card Gradient Color (used if no image)"
                value={project.gradientColor}
                onChange={(val) => updateProject(pIndex, 'gradientColor', val)}
                options={gradientOptions}
                hint="The gradient color for the project card background. Used as fallback if no image is provided."
              />
            </div>
          ))}
        </div>

        {data.projects.length < 12 && (
          <button
            onClick={addProject}
            className="w-full py-4 border-2 border-dashed border-dark-border rounded-xl text-text-muted hover:border-accent/40 hover:text-accent hover:bg-accent/5 transition-all text-sm font-medium"
          >
            + Add Another Project
          </button>
        )}
      </SubSection>
    </div>
  );
}
