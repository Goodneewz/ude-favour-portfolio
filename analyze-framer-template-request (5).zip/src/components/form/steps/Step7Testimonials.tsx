import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, TextArea, UrlInput, SubSection, InfoBanner, StarRating } from '../FormInputs';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

export function Step7Testimonials({ data, onChange }: Props) {
  const updateTestimonial = (index: number, field: string, value: string | number) => {
    const newTestimonials = [...data.testimonials];
    newTestimonials[index] = { ...newTestimonials[index], [field]: value };
    onChange({ testimonials: newTestimonials });
  };

  const addTestimonial = () => {
    onChange({
      testimonials: [...data.testimonials, {
        name: '', role: '', company: '', content: '', rating: 5, avatarUrl: '',
      }],
    });
  };

  const removeTestimonial = (index: number) => {
    if (data.testimonials.length > 1) {
      onChange({ testimonials: data.testimonials.filter((_, i) => i !== index) });
    }
  };

  return (
    <div className="space-y-10">
      <SectionTitle
        step={7}
        title="Client"
        highlight="Testimonials"
        subtitle="Social proof is powerful. Add testimonials from clients, colleagues, or collaborators who can vouch for your skills and professionalism. Real quotes from real people build trust."
      />

      <SubSection title="Section Heading" description="Customize the heading for your Testimonials section">
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Heading Text"
            placeholder="e.g., What clients"
            value={data.testimonialsHeading}
            onChange={(val) => onChange({ testimonialsHeading: val })}
          />
          <TextInput
            label="Heading Highlight (Gradient)"
            placeholder="e.g., say"
            value={data.testimonialsHeadingHighlight}
            onChange={(val) => onChange({ testimonialsHeadingHighlight: val })}
          />
        </div>
        <TextArea
          label="Testimonials Section Subtitle"
          placeholder="e.g., Don't just take my word for it — hear from the people I've worked with."
          value={data.testimonialsSubtitle}
          onChange={(val) => onChange({ testimonialsSubtitle: val })}
          rows={2}
          maxLength={200}
        />
      </SubSection>

      <SubSection title="Testimonials" description="Add reviews from your clients or collaborators">
        <InfoBanner
          type="tip"
          title="✍️ Testimonial tips"
          description="The best testimonials are specific about results and experience. Instead of 'Great work!', something like 'They completely transformed our web presence and increased conversions by 40%' is much more impactful. Ask clients for permission before using their quotes."
        />

        <div className="space-y-6">
          {data.testimonials.map((testimonial, tIndex) => (
            <div key={tIndex} className="relative bg-dark border border-dark-border rounded-2xl p-6 space-y-5">
              {data.testimonials.length > 1 && (
                <button
                  onClick={() => removeTestimonial(tIndex)}
                  className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-dark-card border border-dark-border flex items-center justify-center text-text-muted hover:text-pink-400 hover:border-pink-400/30 transition-all text-xs"
                >
                  ✕
                </button>
              )}

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-accent/10 text-accent rounded-lg text-xs font-semibold">
                  Testimonial #{tIndex + 1}
                </span>
              </div>

              <div className="grid sm:grid-cols-2 gap-5">
                <TextInput
                  label="Client Name"
                  placeholder="e.g., Sarah Mitchell"
                  value={testimonial.name}
                  onChange={(val) => updateTestimonial(tIndex, 'name', val)}
                  required
                />
                <TextInput
                  label="Client Role / Title"
                  placeholder="e.g., CEO, Product Manager, Founder"
                  value={testimonial.role}
                  onChange={(val) => updateTestimonial(tIndex, 'role', val)}
                />
              </div>

              <TextInput
                label="Company / Organization"
                placeholder="e.g., TechVentures, Startify, Google"
                value={testimonial.company}
                onChange={(val) => updateTestimonial(tIndex, 'company', val)}
                hint="The company or organization the client is associated with."
              />

              <TextArea
                label="Testimonial Quote"
                placeholder="e.g., Working with [Your Name] was an absolute pleasure. They understood our vision from day one and delivered a product that truly represents our brand. Our website traffic increased by 60% within the first month."
                value={testimonial.content}
                onChange={(val) => updateTestimonial(tIndex, 'content', val)}
                rows={4}
                required
                hint="The actual quote from your client. Write it in first person as they would say it. Be specific about results and experience."
                maxLength={400}
              />

              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-secondary">Rating</label>
                <StarRating
                  value={testimonial.rating}
                  onChange={(val) => updateTestimonial(tIndex, 'rating', val)}
                />
              </div>

              <UrlInput
                label="Client Avatar / Photo URL (Optional)"
                placeholder="https://example.com/client-photo.jpg"
                value={testimonial.avatarUrl}
                onChange={(val) => updateTestimonial(tIndex, 'avatarUrl', val)}
                hint="Optional: URL to the client's profile photo. If left empty, their initials will be shown in a colored circle instead."
              />
            </div>
          ))}
        </div>

        {data.testimonials.length < 10 && (
          <button
            onClick={addTestimonial}
            className="w-full py-4 border-2 border-dashed border-dark-border rounded-xl text-text-muted hover:border-accent/40 hover:text-accent hover:bg-accent/5 transition-all text-sm font-medium"
          >
            + Add Another Testimonial
          </button>
        )}
      </SubSection>
    </div>
  );
}
