import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, TextArea, ToggleSwitch, SubSection, InfoBanner } from '../FormInputs';
import { Mail, Phone, MapPin } from 'lucide-react';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

const platformSuggestions = [
  'GitHub', 'LinkedIn', 'Twitter', 'Dribbble', 'Behance', 'Instagram',
  'YouTube', 'Medium', 'Dev.to', 'CodePen', 'Figma Community', 'Discord',
  'Twitch', 'TikTok', 'Facebook', 'Threads', 'Mastodon', 'Bluesky', 'Hashnode',
];

export function Step8Contact({ data, onChange }: Props) {
  const updateSocialLink = (index: number, field: string, value: string) => {
    const newLinks = [...data.socialLinks];
    newLinks[index] = { ...newLinks[index], [field]: value };
    onChange({ socialLinks: newLinks });
  };

  const addSocialLink = () => {
    onChange({
      socialLinks: [...data.socialLinks, { platform: '', url: '' }],
    });
  };

  const removeSocialLink = (index: number) => {
    if (data.socialLinks.length > 1) {
      onChange({ socialLinks: data.socialLinks.filter((_, i) => i !== index) });
    }
  };

  return (
    <div className="space-y-10">
      <SectionTitle
        step={8}
        title="Contact &"
        highlight="Social Links"
        subtitle="How can people reach you? Add all your contact details and social media profiles so visitors can connect with you through their preferred channel."
      />

      <SubSection title="Section Heading" description="Customize the heading for your Contact section">
        <div className="grid sm:grid-cols-2 gap-5">
          <TextInput
            label="Heading Text"
            placeholder="e.g., Let's work"
            value={data.contactHeading}
            onChange={(val) => onChange({ contactHeading: val })}
          />
          <TextInput
            label="Heading Highlight (Gradient)"
            placeholder="e.g., together"
            value={data.contactHeadingHighlight}
            onChange={(val) => onChange({ contactHeadingHighlight: val })}
          />
        </div>
        <TextArea
          label="Contact Section Subtitle"
          placeholder="e.g., Have a project in mind? Let's discuss how I can help bring your vision to life."
          value={data.contactSubtitle}
          onChange={(val) => onChange({ contactSubtitle: val })}
          rows={2}
          maxLength={200}
        />
      </SubSection>

      <SubSection title="Contact Information" description="Your direct contact details">
        <TextInput
          label="Email Address"
          placeholder="e.g., hello@yourdomain.com, john@gmail.com"
          value={data.contactEmail}
          onChange={(val) => onChange({ contactEmail: val })}
          required
          type="email"
          icon={<Mail size={16} />}
          hint="This is the primary email address visitors will use to contact you. It also appears as a clickable mailto: link."
        />

        <TextInput
          label="Phone Number"
          placeholder="e.g., +1 (555) 123-4567, +234 xxx xxxx"
          value={data.contactPhone}
          onChange={(val) => onChange({ contactPhone: val })}
          type="tel"
          icon={<Phone size={16} />}
          hint="Optional: Your phone number for direct contact. Leave blank if you prefer not to share it."
        />

        <TextInput
          label="Location"
          placeholder="e.g., San Francisco, CA | Lagos, Nigeria | Remote"
          value={data.contactLocation}
          onChange={(val) => onChange({ contactLocation: val })}
          icon={<MapPin size={16} />}
          hint="Your city, state/country, or just 'Remote' if you work from anywhere. This helps clients understand your timezone and availability."
        />
      </SubSection>

      <SubSection title="Social Media & Online Profiles" description="All your social media links and professional profiles">
        <InfoBanner
          type="info"
          title="🔗 Social links"
          description="These appear in the Contact section as clickable buttons. Add as many platforms as you're active on. Only add links to profiles you actively maintain — quality over quantity."
        />

        <div className="space-y-4">
          {data.socialLinks.map((link, sIndex) => (
            <div key={sIndex} className="relative flex items-start gap-3 bg-dark border border-dark-border rounded-xl p-4">
              {data.socialLinks.length > 1 && (
                <button
                  onClick={() => removeSocialLink(sIndex)}
                  className="absolute top-3 right-3 w-7 h-7 rounded-lg bg-dark-card border border-dark-border flex items-center justify-center text-text-muted hover:text-pink-400 hover:border-pink-400/30 transition-all text-xs shrink-0"
                >
                  ✕
                </button>
              )}

              <span className="text-xs text-text-muted font-mono w-6 pt-3 shrink-0">#{sIndex + 1}</span>

              <div className="flex-1 space-y-3 pr-8">
                <div>
                  <label className="block text-xs text-text-muted mb-1.5">Platform Name</label>
                  <input
                    type="text"
                    value={link.platform}
                    onChange={(e) => updateSocialLink(sIndex, 'platform', e.target.value)}
                    placeholder="e.g., GitHub, LinkedIn, Twitter"
                    className="w-full px-3 py-2.5 bg-dark-card border border-dark-border rounded-lg text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 transition-all text-sm"
                    list={`platforms-${sIndex}`}
                  />
                  <datalist id={`platforms-${sIndex}`}>
                    {platformSuggestions.map(p => (
                      <option key={p} value={p} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="block text-xs text-text-muted mb-1.5">Profile URL</label>
                  <input
                    type="url"
                    value={link.url}
                    onChange={(e) => updateSocialLink(sIndex, 'url', e.target.value)}
                    placeholder="https://github.com/yourusername"
                    className="w-full px-3 py-2.5 bg-dark-card border border-dark-border rounded-lg text-text-primary placeholder:text-text-muted/50 focus:outline-none focus:border-accent/50 transition-all text-sm"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {data.socialLinks.length < 15 && (
          <button
            onClick={addSocialLink}
            className="w-full py-3 border-2 border-dashed border-dark-border rounded-xl text-text-muted hover:border-accent/40 hover:text-accent hover:bg-accent/5 transition-all text-sm font-medium"
          >
            + Add Another Social Link
          </button>
        )}
      </SubSection>

      <SubSection title="Contact Form" description="Allow visitors to send you messages directly">
        <ToggleSwitch
          label="Enable Contact Form"
          checked={data.contactFormEnabled}
          onChange={(val) => onChange({ contactFormEnabled: val })}
          hint="When enabled, a contact form (Name, Email, Subject, Message) appears in the Contact section so visitors can message you directly from the website."
        />
      </SubSection>
    </div>
  );
}
