import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, TextInput, SubSection, InfoBanner } from '../FormInputs';

interface Props {
  data: PortfolioFormData;
  onChange: (data: Partial<PortfolioFormData>) => void;
}

export function Step9Footer({ data, onChange }: Props) {
  return (
    <div className="space-y-10">
      <SectionTitle
        step={9}
        title="Footer &"
        highlight="Credits"
        subtitle="The footer sits at the very bottom of your portfolio. It includes your branding, quick navigation links, copyright info, and a personal touch."
      />

      <SubSection title="Footer Content" description="The text that appears at the bottom of your site">
        <TextInput
          label="Footer Tagline"
          placeholder="e.g., Made with ❤️ and lots of coffee, Built with passion and purpose"
          value={data.footerTagline}
          onChange={(val) => onChange({ footerTagline: val })}
          hint="A fun or personal tagline that appears in the footer. Use emojis if you'd like! This adds a human touch."
        />

        <TextInput
          label="Copyright Text"
          placeholder="e.g., © 2024 YourName. All rights reserved."
          value={data.footerCopyright}
          onChange={(val) => onChange({ footerCopyright: val })}
          hint="The copyright line. The current year will be auto-generated. You can include your name, brand name, or company name."
        />

        <TextInput
          label="Design Credit"
          placeholder="e.g., Designed & Developed by Your Name"
          value={data.footerDesignCredit}
          onChange={(val) => onChange({ footerDesignCredit: val })}
          hint="Credit line for who designed and built the portfolio. This appears on the right side of the footer."
        />
      </SubSection>

      <InfoBanner
        type="tip"
        title="💡 Footer elements"
        description="The footer automatically includes: your logo/brand name from Step 1, navigation links to all sections (Home, About, Services, Work, Contact), a 'Back to top' button, and the copyright/credit text you enter here."
      />
    </div>
  );
}
