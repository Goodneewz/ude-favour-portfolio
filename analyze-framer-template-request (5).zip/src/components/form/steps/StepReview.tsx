import type { PortfolioFormData } from '@/types/formData';
import { SectionTitle, InfoBanner } from '../FormInputs';
import { CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';

interface Props {
  data: PortfolioFormData;
}

function ReviewCard({ title, items, status }: {
  title: string;
  items: { label: string; value: string; filled: boolean }[];
  status: 'complete' | 'partial' | 'empty';
}) {
  const statusColor = {
    complete: 'border-green-500/30 bg-green-500/5',
    partial: 'border-yellow-500/30 bg-yellow-500/5',
    empty: 'border-dark-border bg-dark-card',
  };

  const statusIcon = {
    complete: <CheckCircle size={18} className="text-green-400" />,
    partial: <AlertCircle size={18} className="text-yellow-400" />,
    empty: <AlertCircle size={18} className="text-text-muted" />,
  };

  const statusLabel = {
    complete: 'Complete',
    partial: 'Partial',
    empty: 'Empty',
  };

  return (
    <div className={`border rounded-xl p-5 ${statusColor[status]}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-text-primary text-sm">{title}</h3>
        <div className="flex items-center gap-1.5">
          {statusIcon[status]}
          <span className="text-xs text-text-muted">{statusLabel[status]}</span>
        </div>
      </div>
      <div className="space-y-2">
        {items.map((item, i) => (
          <div key={i} className="flex items-center justify-between text-xs">
            <span className="text-text-muted">{item.label}</span>
            <span className={`truncate max-w-[200px] text-right ${item.filled ? 'text-text-secondary' : 'text-text-muted/40 italic'}`}>
              {item.value || 'Not filled'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function getSectionStatus(items: { filled: boolean }[]): 'complete' | 'partial' | 'empty' {
  const filledCount = items.filter(i => i.filled).length;
  if (filledCount === items.length) return 'complete';
  if (filledCount > 0) return 'partial';
  return 'empty';
}

export function StepReview({ data }: Props) {
  const sections = [
    {
      title: '1. Identity & Branding',
      items: [
        { label: 'Full Name', value: data.fullName, filled: !!data.fullName },
        { label: 'Brand Name', value: data.brandName, filled: !!data.brandName },
        { label: 'Logo Initials', value: data.logoInitials, filled: !!data.logoInitials },
        { label: 'Tagline', value: data.tagline, filled: !!data.tagline },
        { label: 'Profile Photo', value: data.profilePhotoUrl ? '✓ Provided' : '', filled: !!data.profilePhotoUrl },
        { label: 'Resume URL', value: data.resumeUrl ? '✓ Provided' : '', filled: !!data.resumeUrl },
      ],
    },
    {
      title: '2. Hero Section',
      items: [
        { label: 'Headline Line 1', value: data.heroHeadlineLine1, filled: !!data.heroHeadlineLine1 },
        { label: 'Headline Line 2', value: data.heroHeadlineLine2, filled: !!data.heroHeadlineLine2 },
        { label: 'Subtitle', value: data.heroSubtitle.slice(0, 50) + (data.heroSubtitle.length > 50 ? '...' : ''), filled: !!data.heroSubtitle },
        { label: 'Stats', value: `${data.stats.filter(s => s.number).length}/4 filled`, filled: data.stats.some(s => !!s.number) },
      ],
    },
    {
      title: '3. Scrolling Ticker',
      items: [
        { label: 'Ticker Items', value: `${data.marqueeItems.length} items`, filled: data.marqueeItems.length > 0 },
      ],
    },
    {
      title: '4. About',
      items: [
        { label: 'Bio Paragraph 1', value: data.aboutParagraph1 ? '✓ Written' : '', filled: !!data.aboutParagraph1 },
        { label: 'Location', value: data.location, filled: !!data.location },
        { label: 'Tech Stack', value: `${data.techStack.length} technologies`, filled: data.techStack.length > 0 },
        { label: 'Skill Cards', value: `${data.skillCards.filter(s => s.title).length}/${data.skillCards.length} filled`, filled: data.skillCards.some(s => !!s.title) },
      ],
    },
    {
      title: '5. Services',
      items: [
        { label: 'Services', value: `${data.services.filter(s => s.title).length}/${data.services.length} filled`, filled: data.services.some(s => !!s.title) },
      ],
    },
    {
      title: '6. Portfolio & Projects',
      items: [
        { label: 'Notion Link', value: data.notionPortfolioLink ? '✓ Provided' : '', filled: !!data.notionPortfolioLink },
        { label: 'Projects', value: `${data.projects.filter(p => p.title).length}/${data.projects.length} filled`, filled: data.projects.some(p => !!p.title) },
        { label: 'Featured', value: `${data.projects.filter(p => p.featured).length} featured`, filled: data.projects.some(p => p.featured) },
      ],
    },
    {
      title: '7. Testimonials',
      items: [
        { label: 'Testimonials', value: `${data.testimonials.filter(t => t.name).length}/${data.testimonials.length} filled`, filled: data.testimonials.some(t => !!t.name) },
      ],
    },
    {
      title: '8. Contact & Social',
      items: [
        { label: 'Email', value: data.contactEmail, filled: !!data.contactEmail },
        { label: 'Phone', value: data.contactPhone, filled: !!data.contactPhone },
        { label: 'Social Links', value: `${data.socialLinks.filter(s => s.url).length} links`, filled: data.socialLinks.some(s => !!s.url) },
      ],
    },
    {
      title: '9. Footer',
      items: [
        { label: 'Tagline', value: data.footerTagline, filled: !!data.footerTagline },
        { label: 'Copyright', value: data.footerCopyright, filled: !!data.footerCopyright },
      ],
    },
    {
      title: '10. Theme',
      items: [
        { label: 'Primary Color', value: data.accentColor, filled: !!data.accentColor },
        { label: 'Secondary Color', value: data.secondaryAccentColor, filled: !!data.secondaryAccentColor },
        { label: 'Font', value: data.fontFamily, filled: !!data.fontFamily },
        { label: 'Dark Mode', value: data.darkMode ? 'Yes' : 'No', filled: true },
      ],
    },
  ];

  const totalFields = sections.reduce((acc, s) => acc + s.items.length, 0);
  const filledFields = sections.reduce((acc, s) => acc + s.items.filter(i => i.filled).length, 0);

  return (
    <div className="space-y-10">
      <SectionTitle
        step={11}
        title="Review &"
        highlight="Generate"
        subtitle="Here's a summary of everything you've entered. Review it, go back to any step to make changes, then hit 'Generate Portfolio' to create your beautiful Landio-inspired portfolio website."
      />

      {/* Overall Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-dark-card border border-dark-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold gradient-text">{filledFields}/{totalFields}</div>
          <p className="text-xs text-text-muted mt-1">Fields Filled</p>
        </div>
        <div className="bg-dark-card border border-dark-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold gradient-text">{data.projects.length}</div>
          <p className="text-xs text-text-muted mt-1">Projects</p>
        </div>
        <div className="bg-dark-card border border-dark-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold gradient-text">{data.testimonials.length}</div>
          <p className="text-xs text-text-muted mt-1">Testimonials</p>
        </div>
      </div>

      {data.notionPortfolioLink && (
        <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-4">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shrink-0">
            <span className="text-black font-bold text-sm">N</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-text-primary">Notion Portfolio Linked</p>
            <p className="text-xs text-text-muted truncate">{data.notionPortfolioLink}</p>
          </div>
          <a href={data.notionPortfolioLink} target="_blank" rel="noopener noreferrer" className="text-accent hover:text-accent-light transition-colors">
            <ExternalLink size={16} />
          </a>
        </div>
      )}

      {/* Section Reviews */}
      <div className="grid sm:grid-cols-2 gap-4">
        {sections.map((section) => (
          <ReviewCard
            key={section.title}
            title={section.title}
            items={section.items}
            status={getSectionStatus(section.items)}
          />
        ))}
      </div>

      <InfoBanner
        type="tip"
        title="🚀 Ready to generate?"
        description="Click 'Generate Portfolio' below to create your Landio-inspired portfolio website. You can always come back and make changes. Fields left empty will use sensible defaults or be hidden from the final portfolio."
      />
    </div>
  );
}
