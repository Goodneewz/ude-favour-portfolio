import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import type { PortfolioFormData } from '@/types/formData';
import {
  Menu, X, Sparkles, ArrowDown, Star, Quote, Send, Mail, MapPin, Phone,
  ArrowUpRight, ExternalLink, Github, Heart, CheckCircle,
  Code2, Palette, Zap, Globe, Smartphone, Layers, Database, Shield, Rocket,
  Camera, PenTool, Monitor, TrendingUp, Search, Cloud,
  Pencil, Download, FileText
} from 'lucide-react';

/* ═══════════════════════════════════════════════════════
   HELPERS
   ═══════════════════════════════════════════════════════ */

function getIcon(type: string, size = 24): React.ReactNode {
  const icons: Record<string, React.ReactNode> = {
    'code': <Code2 size={size} />,
    'palette': <Palette size={size} />,
    'zap': <Zap size={size} />,
    'globe': <Globe size={size} />,
    'smartphone': <Smartphone size={size} />,
    'layers': <Layers size={size} />,
    'database': <Database size={size} />,
    'shield': <Shield size={size} />,
    'rocket': <Rocket size={size} />,
    'camera': <Camera size={size} />,
    'pen-tool': <PenTool size={size} />,
    'monitor': <Monitor size={size} />,
    'trending-up': <TrendingUp size={size} />,
    'search': <Search size={size} />,
    'cloud': <Cloud size={size} />,
    'brain': <Zap size={size} />,
    'bot': <Monitor size={size} />,
    'video': <Camera size={size} />,
    'megaphone': <ArrowUpRight size={size} />,
  };
  return icons[type] || <Code2 size={size} />;
}

const gradientCSSMap: Record<string, string> = {
  'from-violet-500 to-purple-600': 'linear-gradient(135deg, #8b5cf6, #9333ea)',
  'from-pink-500 to-rose-600': 'linear-gradient(135deg, #ec4899, #e11d48)',
  'from-blue-500 to-cyan-600': 'linear-gradient(135deg, #3b82f6, #0891b2)',
  'from-green-500 to-emerald-600': 'linear-gradient(135deg, #22c55e, #059669)',
  'from-yellow-500 to-orange-500': 'linear-gradient(135deg, #eab308, #f97316)',
  'from-red-500 to-pink-500': 'linear-gradient(135deg, #ef4444, #ec4899)',
  'from-indigo-500 to-blue-600': 'linear-gradient(135deg, #6366f1, #2563eb)',
  'from-teal-500 to-green-500': 'linear-gradient(135deg, #14b8a6, #22c55e)',
  'from-amber-500 to-red-500': 'linear-gradient(135deg, #f59e0b, #ef4444)',
  'from-fuchsia-500 to-purple-600': 'linear-gradient(135deg, #d946ef, #9333ea)',
};

const googleFontMap: Record<string, string> = {
  'Inter': 'Inter:wght@100;200;300;400;500;600;700;800;900',
  'Poppins': 'Poppins:wght@100;200;300;400;500;600;700;800;900',
  'DM Sans': 'DM+Sans:wght@100;200;300;400;500;600;700;800;900',
  'Space Grotesk': 'Space+Grotesk:wght@300;400;500;600;700',
  'Outfit': 'Outfit:wght@100;200;300;400;500;600;700;800;900',
  'Sora': 'Sora:wght@100;200;300;400;500;600;700;800',
  'Manrope': 'Manrope:wght@200;300;400;500;600;700;800',
  'Plus Jakarta Sans': 'Plus+Jakarta+Sans:wght@200;300;400;500;600;700;800',
};

const testimonialGradients = [
  'linear-gradient(135deg, #8b5cf6, #9333ea)',
  'linear-gradient(135deg, #ec4899, #e11d48)',
  'linear-gradient(135deg, #3b82f6, #0891b2)',
  'linear-gradient(135deg, #22c55e, #059669)',
  'linear-gradient(135deg, #f59e0b, #f97316)',
  'linear-gradient(135deg, #6366f1, #2563eb)',
];

function getInitials(name: string): string {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

/* ═══════════════════════════════════════════════════════
   GRADIENT TEXT COMPONENT
   ═══════════════════════════════════════════════════════ */

function GText({ children, gradient }: { children: React.ReactNode; gradient: string }) {
  return (
    <span
      style={{
        background: gradient,
        backgroundSize: '200% 200%',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
        backgroundClip: 'text',
      }}
    >
      {children}
    </span>
  );
}

/* ═══════════════════════════════════════════════════════
   PROPS
   ═══════════════════════════════════════════════════════ */

interface PortfolioSiteProps {
  data: PortfolioFormData;
  onEdit: () => void;
  onDownloadJson: () => void;
}

/* ═══════════════════════════════════════════════════════
   FLOATING TOOLBAR
   ═══════════════════════════════════════════════════════ */

function FloatingToolbar({ onEdit, onDownload, accent }: {
  onEdit: () => void;
  onDownload: () => void;
  accent: string;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <motion.div
      className="fixed bottom-6 right-6 z-[100] flex flex-col items-end gap-2"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1, duration: 0.5 }}
    >
      <AnimatePresence>
        {expanded && (
          <>
            <motion.button
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              transition={{ duration: 0.2 }}
              onClick={onEdit}
              className="flex items-center gap-2 px-5 py-3 bg-white text-gray-900 font-semibold rounded-full shadow-2xl hover:bg-gray-100 transition-colors text-sm"
            >
              <Pencil size={16} />
              Edit Details
            </motion.button>
            <motion.button
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              transition={{ duration: 0.2, delay: 0.05 }}
              onClick={onDownload}
              className="flex items-center gap-2 px-5 py-3 bg-dark-card border border-dark-border text-text-primary font-semibold rounded-full shadow-2xl hover:bg-dark-secondary transition-colors text-sm"
            >
              <Download size={16} />
              Download JSON
            </motion.button>
          </>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setExpanded(!expanded)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-14 h-14 rounded-full shadow-2xl flex items-center justify-center text-white transition-all"
        style={{ background: accent }}
      >
        {expanded ? <X size={22} /> : <Pencil size={22} />}
      </motion.button>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════
   NAVBAR
   ═══════════════════════════════════════════════════════ */

function SiteNavbar({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const hasAbout = !!(data.aboutParagraph1 || data.aboutParagraph2);
  const hasServices = data.services.some(s => s.title);
  const hasWork = data.projects.some(p => p.title);
  const hasTestimonials = data.testimonials.some(t => t.name && t.content);

  const navLinks = [
    { label: 'Home', href: '#home', show: true },
    { label: 'About', href: '#about', show: hasAbout },
    { label: 'Services', href: '#services', show: hasServices },
    { label: 'Work', href: '#work', show: hasWork },
    { label: 'Testimonials', href: '#testimonials', show: hasTestimonials },
    { label: 'Contact', href: '#contact', show: true },
  ].filter(l => l.show);

  const brandName = data.brandName || data.fullName || 'Portfolio';
  const initials = data.logoInitials || (data.fullName ? data.fullName[0].toUpperCase() : 'P');
  const ctaText = data.primaryCtaText || 'Let\'s Talk';

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-dark/80 backdrop-blur-xl border-b border-dark-border/50'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <motion.a href="#home" className="flex items-center gap-2 group" whileHover={{ scale: 1.02 }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: accent }}>
                <span className="text-white font-bold text-lg">{initials}</span>
              </div>
              <span className="text-text-primary font-semibold text-xl tracking-tight">
                {brandName.includes('.') ? (
                  <>
                    {brandName.split('.')[0]}
                    <span style={{ color: data.accentColor }}>.</span>
                    {brandName.split('.').slice(1).join('.')}
                  </>
                ) : (
                  <>
                    {brandName}
                    <span style={{ color: data.accentColor }}>.</span>
                  </>
                )}
              </span>
            </motion.a>

            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="px-4 py-2 text-sm text-text-secondary hover:text-text-primary transition-colors duration-300 rounded-lg hover:bg-white/5"
                >
                  {link.label}
                </a>
              ))}
            </div>

            <div className="hidden md:flex items-center gap-4">
              {data.resumeUrl && (
                <a
                  href={data.resumeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-4 py-2 text-sm text-text-secondary hover:text-text-primary transition-colors"
                >
                  <FileText size={14} />
                  Resume
                </a>
              )}
              <motion.a
                href="#contact"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="px-6 py-2.5 text-white text-sm font-medium rounded-full hover:shadow-lg transition-shadow duration-300"
                style={{ background: accent, boxShadow: `0 4px 20px ${data.accentColor}40` }}
              >
                {ctaText}
              </motion.a>
            </div>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 text-text-secondary hover:text-text-primary transition-colors"
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </motion.nav>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-dark/95 backdrop-blur-xl pt-24 px-6"
          >
            <div className="flex flex-col gap-2">
              {navLinks.map((link, i) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="px-4 py-4 text-2xl font-medium text-text-secondary hover:text-text-primary border-b border-dark-border/50 transition-colors"
                >
                  {link.label}
                </motion.a>
              ))}
              <motion.a
                href="#contact"
                onClick={() => setMobileOpen(false)}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="mt-6 px-8 py-4 text-white text-lg font-medium rounded-full text-center"
                style={{ background: accent }}
              >
                {ctaText}
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

/* ═══════════════════════════════════════════════════════
   HERO SECTION
   ═══════════════════════════════════════════════════════ */

function SiteHero({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const line1 = data.heroHeadlineLine1 || 'I create';
  const line2 = data.heroHeadlineLine2 || 'amazing things';
  const line3 = data.heroHeadlineLine3;
  const subtitle = data.heroSubtitle || 'Welcome to my portfolio. Explore my work and get in touch.';

  const availabilityColors: Record<string, { bg: string; text: string }> = {
    available: { bg: 'rgba(34, 197, 94, 0.1)', text: '#22c55e' },
    busy: { bg: 'rgba(234, 179, 8, 0.1)', text: '#eab308' },
    unavailable: { bg: 'rgba(239, 68, 68, 0.1)', text: '#ef4444' },
    custom: { bg: `${data.accentColor}15`, text: data.accentColor },
  };

  const avail = availabilityColors[data.availabilityStatus] || availabilityColors.available;
  const activeStats = data.stats.filter(s => s.number && s.label);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden noise-bg">
      <div className="glow-orb w-[500px] h-[500px] top-[-10%] left-[-10%]" style={{ backgroundColor: `${data.accentColor}30` }} />
      <div className="glow-orb w-[400px] h-[400px] bottom-[-5%] right-[-5%]" style={{ backgroundColor: `${data.secondaryAccentColor}20`, animationDelay: '2s' }} />
      <div className="glow-orb w-[300px] h-[300px] top-[50%] left-[50%]" style={{ backgroundColor: `${data.accentColor}15`, animationDelay: '1s' }} />

      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
        backgroundSize: '60px 60px'
      }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 text-center">
        {data.availabilityText && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8"
            style={{ backgroundColor: avail.bg, border: `1px solid ${avail.text}30` }}
          >
            <Sparkles size={14} style={{ color: avail.text }} />
            <span className="text-sm font-medium" style={{ color: avail.text }}>{data.availabilityText}</span>
          </motion.div>
        )}

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[0.95] mb-6"
        >
          <span className="text-text-primary">{line1} </span>
          <br />
          <GText gradient={accent}>{line2}</GText>
          {line3 && (
            <>
              <br />
              <span className="text-text-primary">{line3}</span>
            </>
          )}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.25 }}
          className="max-w-2xl mx-auto text-lg md:text-xl text-text-secondary leading-relaxed mb-12"
        >
          {subtitle}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <motion.a
            href={data.primaryCtaLink || '#work'}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="px-8 py-4 text-white font-semibold rounded-full transition-all duration-300 text-lg"
            style={{ background: accent, boxShadow: `0 8px 30px ${data.accentColor}40` }}
          >
            {data.primaryCtaText || 'View My Work'}
          </motion.a>
          {data.secondaryCtaText && (
            <motion.a
              href={data.secondaryCtaLink || '#about'}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="px-8 py-4 border border-dark-border text-text-primary font-semibold rounded-full hover:bg-white/5 hover:border-text-muted transition-all duration-300 text-lg"
            >
              {data.secondaryCtaText}
            </motion.a>
          )}
        </motion.div>

        {activeStats.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="flex flex-wrap items-center justify-center gap-8 md:gap-16 mt-20 pt-12 border-t border-dark-border/50"
          >
            {activeStats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl md:text-4xl font-bold">
                  <GText gradient={accent}>{stat.number}</GText>
                </div>
                <div className="text-sm text-text-muted mt-1">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        )}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="flex flex-col items-center gap-2 text-text-muted"
        >
          <span className="text-xs tracking-widest uppercase">Scroll</span>
          <ArrowDown size={16} />
        </motion.div>
      </motion.div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════
   MARQUEE / TICKER
   ═══════════════════════════════════════════════════════ */

function SiteMarquee({ data }: { data: PortfolioFormData }) {
  if (data.marqueeItems.length === 0) return null;

  const items = [...data.marqueeItems, ...data.marqueeItems, ...data.marqueeItems, ...data.marqueeItems];

  return (
    <div className="py-8 bg-dark-secondary border-y border-dark-border overflow-hidden">
      <motion.div
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: Math.max(20, data.marqueeItems.length * 3), repeat: Infinity, ease: 'linear' }}
        className="flex items-center gap-8 whitespace-nowrap"
      >
        {items.map((item, i) => (
          <span key={i} className="flex items-center gap-8">
            <span className="text-lg font-medium text-text-muted">{item}</span>
            <span className="text-sm" style={{ color: data.accentColor }}>✦</span>
          </span>
        ))}
      </motion.div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   ABOUT SECTION
   ═══════════════════════════════════════════════════════ */

function SiteAbout({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const { ref, isInView } = useInView(0.15);

  if (!data.aboutParagraph1 && !data.aboutParagraph2 && !data.aboutParagraph3) return null;

  const filledCards = data.skillCards.filter(c => c.title);

  return (
    <section id="about" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[400px] h-[400px] top-[20%] right-[-10%]" style={{ backgroundColor: `${data.accentColor}15` }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: data.accentColor }}>About Me</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            {data.aboutHeading || 'Passionate about creating'}
            <br />
            <GText gradient={accent}>{data.aboutHeadingHighlight || 'meaningful experiences'}</GText>.
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="space-y-6"
          >
            {data.profilePhotoUrl && (
              <div className="mb-6">
                <img
                  src={data.profilePhotoUrl}
                  alt={data.fullName || 'Profile'}
                  className="w-24 h-24 rounded-2xl object-cover border-2"
                  style={{ borderColor: `${data.accentColor}40` }}
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
              </div>
            )}

            {data.aboutParagraph1 && (
              <p className="text-lg text-text-secondary leading-relaxed">
                {data.aboutParagraph1}
              </p>
            )}

            {data.aboutParagraph2 && (
              <p className="text-lg text-text-secondary leading-relaxed">
                {data.aboutParagraph2}
              </p>
            )}

            {data.aboutParagraph3 && (
              <p className="text-lg text-text-secondary leading-relaxed">
                {data.aboutParagraph3}
              </p>
            )}

            {(data.location || data.yearsExperience) && (
              <div className="flex flex-wrap gap-4 pt-2">
                {data.location && (
                  <div className="flex items-center gap-2 text-text-muted">
                    <MapPin size={16} style={{ color: data.accentColor }} />
                    <span className="text-sm">{data.location}</span>
                  </div>
                )}
                {data.yearsExperience && (
                  <div className="flex items-center gap-2 text-text-muted">
                    <Zap size={16} style={{ color: data.accentColor }} />
                    <span className="text-sm">{data.yearsExperience} years experience</span>
                  </div>
                )}
              </div>
            )}

            {data.techStack.length > 0 && (
              <div className="pt-6">
                <h3 className="text-sm font-medium text-text-muted uppercase tracking-widest mb-4">Tech Stack</h3>
                <div className="flex flex-wrap gap-2">
                  {data.techStack.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1.5 text-sm text-text-secondary bg-dark-card border border-dark-border rounded-lg transition-all duration-300 cursor-default"
                      onMouseEnter={(e) => {
                        (e.target as HTMLElement).style.borderColor = `${data.accentColor}60`;
                        (e.target as HTMLElement).style.color = data.accentColor;
                      }}
                      onMouseLeave={(e) => {
                        (e.target as HTMLElement).style.borderColor = '';
                        (e.target as HTMLElement).style.color = '';
                      }}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </motion.div>

          {filledCards.length > 0 && (
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="grid grid-cols-2 gap-4"
            >
              {filledCards.map((card, i) => (
                <motion.div
                  key={card.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
                  className="gradient-border p-6 rounded-xl card-hover group cursor-default"
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors"
                    style={{ backgroundColor: `${data.accentColor}15`, color: data.accentColor }}
                  >
                    {getIcon(card.iconType)}
                  </div>
                  <h3 className="text-text-primary font-semibold mb-1">{card.title}</h3>
                  <p className="text-sm text-text-muted">{card.description}</p>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════
   SERVICES SECTION
   ═══════════════════════════════════════════════════════ */

function SiteServices({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const { ref, isInView } = useInView(0.1);
  const filledServices = data.services.filter(s => s.title);

  if (filledServices.length === 0) return null;

  return (
    <section id="services" className="relative py-32 bg-dark-secondary noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] bottom-[-10%] left-[-10%]" style={{ backgroundColor: `${data.secondaryAccentColor}15` }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: data.accentColor }}>Services</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            {data.servicesHeading || 'What I'} <GText gradient={accent}>{data.servicesHeadingHighlight || 'do best'}</GText>.
          </h2>
          {data.servicesSubtitle && (
            <p className="max-w-2xl mx-auto text-lg text-text-secondary mt-6">{data.servicesSubtitle}</p>
          )}
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {filledServices.map((service, i) => {
            const filledFeatures = service.features.filter(f => f);
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.15 + i * 0.1 }}
                className="group relative bg-dark-card border border-dark-border rounded-2xl p-8 card-hover overflow-hidden"
              >
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
                  style={{ background: `linear-gradient(135deg, ${data.accentColor}08, ${data.secondaryAccentColor}08)` }}
                />

                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-6">
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300"
                      style={{ backgroundColor: `${data.accentColor}15`, color: data.accentColor }}
                    >
                      {getIcon(service.iconType, 28)}
                    </div>
                    <ArrowUpRight size={20} className="text-text-muted group-hover:text-accent transition-colors duration-300" />
                  </div>

                  <h3 className="text-xl font-bold text-text-primary mb-3">{service.title}</h3>
                  <p className="text-text-secondary leading-relaxed mb-6">{service.description}</p>

                  {filledFeatures.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {filledFeatures.map((feat) => (
                        <span
                          key={feat}
                          className="px-3 py-1 text-xs font-medium text-text-muted bg-dark border border-dark-border rounded-full"
                        >
                          {feat}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════
   WORK / PORTFOLIO SECTION
   ═══════════════════════════════════════════════════════ */

function SiteWork({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const { ref, isInView } = useInView(0.05);
  const filledProjects = data.projects.filter(p => p.title);
  const featuredProjects = filledProjects.filter(p => p.featured);
  const regularProjects = filledProjects.filter(p => !p.featured);

  if (filledProjects.length === 0) return null;

  return (
    <section id="work" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] top-[30%] right-[-15%]" style={{ backgroundColor: `${data.accentColor}15` }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row md:items-end md:justify-between mb-16"
        >
          <div>
            <span className="text-sm font-medium uppercase tracking-widest" style={{ color: data.accentColor }}>Portfolio</span>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
              {data.workHeading || 'Selected'} <GText gradient={accent}>{data.workHeadingHighlight || 'works'}</GText>.
            </h2>
          </div>
          <p className="max-w-md text-text-secondary mt-4 md:mt-0">
            {data.workSubtitle || 'A curated selection of projects that showcase my expertise.'}
          </p>
        </motion.div>

        {data.notionPortfolioLink && (
          <motion.a
            href={data.notionPortfolioLink}
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-4 mb-8 hover:bg-white/8 transition-colors group"
          >
            <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shrink-0">
              <span className="text-black font-bold text-sm">N</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-text-primary">View full portfolio on Notion</p>
              <p className="text-xs text-text-muted truncate">{data.notionPortfolioLink}</p>
            </div>
            <ExternalLink size={16} className="text-text-muted group-hover:text-text-primary transition-colors shrink-0" />
          </motion.a>
        )}

        {featuredProjects.length > 0 && (
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            {featuredProjects.map((project, i) => {
              const bgGradient = gradientCSSMap[project.gradientColor] || `linear-gradient(135deg, ${data.accentColor}, ${data.secondaryAccentColor})`;
              return (
                <motion.div
                  key={project.title}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.15 + i * 0.1 }}
                  className="group relative bg-dark-card border border-dark-border rounded-2xl overflow-hidden card-hover"
                >
                  <div className="h-64 w-full relative overflow-hidden">
                    {project.imageUrl ? (
                      <img
                        src={project.imageUrl}
                        alt={project.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                          ((e.target as HTMLImageElement).parentElement as HTMLElement).style.background = bgGradient;
                        }}
                      />
                    ) : (
                      <div className="w-full h-full" style={{ background: bgGradient }} />
                    )}
                    <div className="absolute inset-0 bg-dark/20 group-hover:bg-dark/10 transition-colors duration-500" />
                    <div className="absolute bottom-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      {project.githubUrl && (
                        <a href={project.githubUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/30 transition-colors">
                          <Github size={18} />
                        </a>
                      )}
                      {project.liveUrl && (
                        <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/30 transition-colors">
                          <ExternalLink size={18} />
                        </a>
                      )}
                    </div>
                  </div>

                  <div className="p-6">
                    {project.category && (
                      <span className="text-xs font-medium uppercase tracking-wider" style={{ color: data.accentColor }}>{project.category}</span>
                    )}
                    <h3 className="text-xl font-bold text-text-primary mt-2 mb-2">{project.title}</h3>
                    {project.description && (
                      <p className="text-text-secondary text-sm leading-relaxed mb-4">{project.description}</p>
                    )}
                    {project.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {project.tags.map(tag => (
                          <span key={tag} className="px-2.5 py-1 text-xs font-medium text-text-muted bg-dark border border-dark-border rounded-md">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {regularProjects.length > 0 && (
          <div className={`grid sm:grid-cols-2 ${regularProjects.length >= 3 ? 'lg:grid-cols-3' : ''} ${regularProjects.length >= 4 ? 'xl:grid-cols-4' : ''} gap-4`}>
            {regularProjects.map((project, i) => {
              const bgGradient = gradientCSSMap[project.gradientColor] || `linear-gradient(135deg, ${data.accentColor}, ${data.secondaryAccentColor})`;
              return (
                <motion.div
                  key={project.title}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + i * 0.08 }}
                  className="group bg-dark-card border border-dark-border rounded-xl p-5 card-hover"
                >
                  <div className="h-3 w-16 rounded-full mb-4" style={{ background: bgGradient }} />
                  {project.category && (
                    <span className="text-xs font-medium uppercase tracking-wider" style={{ color: data.accentColor }}>{project.category}</span>
                  )}
                  <h3 className="text-base font-bold text-text-primary mt-1 mb-2 group-hover:text-accent transition-colors">{project.title}</h3>
                  {project.description && (
                    <p className="text-text-muted text-xs leading-relaxed mb-3">{project.description}</p>
                  )}
                  {project.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {project.tags.slice(0, 4).map(tag => (
                        <span key={tag} className="px-2 py-0.5 text-[10px] font-medium text-text-muted bg-dark border border-dark-border rounded">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2">
                    {project.liveUrl && (
                      <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-text-muted hover:text-text-primary transition-colors flex items-center gap-1">
                        <ExternalLink size={10} /> Live
                      </a>
                    )}
                    {project.githubUrl && (
                      <a href={project.githubUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-text-muted hover:text-text-primary transition-colors flex items-center gap-1">
                        <Github size={10} /> Code
                      </a>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════
   TESTIMONIALS SECTION
   ═══════════════════════════════════════════════════════ */

function SiteTestimonials({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const { ref, isInView } = useInView(0.1);
  const filledTestimonials = data.testimonials.filter(t => t.name && t.content);

  if (filledTestimonials.length === 0) return null;

  return (
    <section id="testimonials" className="relative py-32 bg-dark-secondary noise-bg" ref={ref}>
      <div className="glow-orb w-[400px] h-[400px] top-[10%] left-[-5%]" style={{ backgroundColor: `${data.accentColor}15` }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: data.accentColor }}>Testimonials</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            {data.testimonialsHeading || 'What clients'} <GText gradient={accent}>{data.testimonialsHeadingHighlight || 'say'}</GText>.
          </h2>
          {data.testimonialsSubtitle && (
            <p className="max-w-2xl mx-auto text-lg text-text-secondary mt-6">{data.testimonialsSubtitle}</p>
          )}
        </motion.div>

        <div className={`grid gap-6 ${filledTestimonials.length === 1 ? 'max-w-xl mx-auto' : filledTestimonials.length === 2 ? 'md:grid-cols-2' : 'md:grid-cols-3'}`}>
          {filledTestimonials.map((testimonial, i) => {
            const avatarGradient = testimonialGradients[i % testimonialGradients.length];
            const initials = getInitials(testimonial.name);
            const roleText = [testimonial.role, testimonial.company].filter(Boolean).join(' at ');

            return (
              <motion.div
                key={testimonial.name + i}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.15 + i * 0.15 }}
                className="group bg-dark-card border border-dark-border rounded-2xl p-8 card-hover relative"
              >
                <Quote size={40} className="absolute top-6 right-6" style={{ color: `${data.accentColor}15` }} />

                {testimonial.rating > 0 && (
                  <div className="flex gap-1 mb-6">
                    {Array.from({ length: testimonial.rating }).map((_, j) => (
                      <Star key={j} size={16} className="fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                )}

                <p className="text-text-secondary leading-relaxed mb-8 relative z-10">
                  &ldquo;{testimonial.content}&rdquo;
                </p>

                <div className="flex items-center gap-3">
                  {testimonial.avatarUrl ? (
                    <img
                      src={testimonial.avatarUrl}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                      onError={(e) => {
                        const el = e.target as HTMLImageElement;
                        el.style.display = 'none';
                        if (el.nextElementSibling) (el.nextElementSibling as HTMLElement).style.display = 'flex';
                      }}
                    />
                  ) : null}
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: avatarGradient,
                      display: testimonial.avatarUrl ? 'none' : 'flex',
                    }}
                  >
                    <span className="text-white text-sm font-bold">{initials}</span>
                  </div>
                  <div>
                    <h4 className="text-text-primary font-semibold">{testimonial.name}</h4>
                    {roleText && <p className="text-text-muted text-sm">{roleText}</p>}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════
   CONTACT SECTION
   ═══════════════════════════════════════════════════════ */

function SiteContact({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const { ref, isInView } = useInView(0.1);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => setFormSubmitted(false), 4000);
  };

  const contactInfo = [
    data.contactEmail ? { icon: <Mail size={20} />, label: 'Email', value: data.contactEmail, href: `mailto:${data.contactEmail}` } : null,
    data.contactPhone ? { icon: <Phone size={20} />, label: 'Phone', value: data.contactPhone, href: `tel:${data.contactPhone.replace(/\s/g, '')}` } : null,
    (data.contactLocation || data.location) ? { icon: <MapPin size={20} />, label: 'Location', value: data.contactLocation || data.location, href: '#' } : null,
  ].filter(Boolean) as { icon: React.ReactNode; label: string; value: string; href: string }[];

  const activeSocials = data.socialLinks.filter(s => s.platform && s.url);

  return (
    <section id="contact" className="relative py-32 overflow-hidden noise-bg" ref={ref}>
      <div className="glow-orb w-[500px] h-[500px] bottom-[-20%] right-[-10%]" style={{ backgroundColor: `${data.accentColor}20` }} />
      <div className="glow-orb w-[300px] h-[300px] top-[10%] left-[-5%]" style={{ backgroundColor: `${data.secondaryAccentColor}15`, animationDelay: '2s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-sm font-medium uppercase tracking-widest" style={{ color: data.accentColor }}>Contact</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mt-4 leading-tight">
            {data.contactHeading || "Let's work"} <GText gradient={accent}>{data.contactHeadingHighlight || 'together'}</GText>.
          </h2>
          {data.contactSubtitle && (
            <p className="max-w-2xl mx-auto text-lg text-text-secondary mt-6">{data.contactSubtitle}</p>
          )}
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-2 space-y-8"
          >
            {contactInfo.length > 0 && (
              <div className="space-y-6">
                {contactInfo.map((info) => (
                  <a key={info.label} href={info.href} className="flex items-start gap-4 group">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-all duration-300"
                      style={{ backgroundColor: `${data.accentColor}15`, color: data.accentColor }}
                    >
                      {info.icon}
                    </div>
                    <div>
                      <p className="text-sm text-text-muted">{info.label}</p>
                      <p className="text-text-primary font-medium group-hover:text-accent transition-colors">{info.value}</p>
                    </div>
                  </a>
                ))}
              </div>
            )}

            {activeSocials.length > 0 && (
              <div className="pt-8 border-t border-dark-border">
                <h3 className="text-sm font-medium text-text-muted uppercase tracking-widest mb-4">Follow Me</h3>
                <div className="flex flex-wrap gap-3">
                  {activeSocials.map((social) => (
                    <a
                      key={social.platform}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2.5 bg-dark-card border border-dark-border rounded-xl text-sm text-text-secondary hover:border-accent/50 hover:text-accent transition-all duration-300 group"
                    >
                      {social.platform}
                      <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  ))}
                </div>
              </div>
            )}

            {data.resumeUrl && (
              <div className="pt-8 border-t border-dark-border">
                <a
                  href={data.resumeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 border border-dark-border rounded-xl text-text-secondary hover:text-text-primary hover:border-text-muted transition-all"
                >
                  <FileText size={18} />
                  Download Resume / CV
                  <ArrowUpRight size={14} />
                </a>
              </div>
            )}
          </motion.div>

          {data.contactFormEnabled && (
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="lg:col-span-3"
            >
              <form onSubmit={handleSubmit} className="bg-dark-card border border-dark-border rounded-2xl p-8 space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-text-secondary mb-2">Name</label>
                    <input
                      type="text"
                      placeholder="John Doe"
                      className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-text-secondary mb-2">Email</label>
                    <input
                      type="email"
                      placeholder="john@example.com"
                      className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">Subject</label>
                  <input
                    type="text"
                    placeholder="Project inquiry"
                    className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">Message</label>
                  <textarea
                    rows={5}
                    placeholder="Tell me about your project..."
                    className="w-full px-4 py-3.5 bg-dark border border-dark-border rounded-xl text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-all resize-none"
                    required
                  />
                </div>

                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 text-white font-semibold rounded-xl hover:shadow-lg transition-shadow flex items-center justify-center gap-2"
                  style={{ background: accent, boxShadow: `0 4px 20px ${data.accentColor}30` }}
                >
                  {formSubmitted ? (
                    <>
                      <CheckCircle size={20} />
                      Message Sent!
                    </>
                  ) : (
                    <>
                      <Send size={18} />
                      Send Message
                    </>
                  )}
                </motion.button>
              </form>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════════════════ */

function SiteFooter({ data, accent }: { data: PortfolioFormData; accent: string }) {
  const brandName = data.brandName || data.fullName || 'Portfolio';
  const initials = data.logoInitials || (data.fullName ? data.fullName[0].toUpperCase() : 'P');

  const hasAbout = !!(data.aboutParagraph1 || data.aboutParagraph2);
  const hasServices = data.services.some(s => s.title);
  const hasWork = data.projects.some(p => p.title);

  const footerLinks = [
    { label: 'Home', href: '#home', show: true },
    { label: 'About', href: '#about', show: hasAbout },
    { label: 'Services', href: '#services', show: hasServices },
    { label: 'Work', href: '#work', show: hasWork },
    { label: 'Contact', href: '#contact', show: true },
  ].filter(l => l.show);

  return (
    <footer className="relative bg-dark-secondary border-t border-dark-border py-16 noise-bg">
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: accent }}>
              <span className="text-white font-bold text-lg">{initials}</span>
            </div>
            <span className="text-text-primary font-semibold text-xl tracking-tight">
              {brandName.includes('.') ? (
                <>
                  {brandName.split('.')[0]}
                  <span style={{ color: data.accentColor }}>.</span>
                  {brandName.split('.').slice(1).join('.')}
                </>
              ) : (
                <>
                  {brandName}
                  <span style={{ color: data.accentColor }}>.</span>
                </>
              )}
            </span>
          </div>

          <nav className="flex flex-wrap items-center justify-center gap-6">
            {footerLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm text-text-secondary hover:text-text-primary transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <motion.a
            href="#home"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-5 py-2.5 border border-dark-border rounded-full text-sm text-text-secondary hover:text-text-primary hover:border-text-muted transition-all"
          >
            ↑ Back to top
          </motion.a>
        </div>

        <div className="mt-12 pt-8 border-t border-dark-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-text-muted flex items-center gap-1">
            {data.footerCopyright || (
              <>
                © {new Date().getFullYear()} {brandName}. All rights reserved.
              </>
            )}
            {data.footerTagline && (
              <span className="ml-2 flex items-center gap-1">
                | {data.footerTagline.includes('❤') || data.footerTagline.includes('heart') ? (
                  data.footerTagline
                ) : (
                  <>Made with <Heart size={14} className="fill-pink-500 text-pink-500" /> {data.footerTagline}</>
                )}
              </span>
            )}
          </p>
          {data.footerDesignCredit && (
            <p className="text-sm text-text-muted">{data.footerDesignCredit}</p>
          )}
        </div>
      </div>
    </footer>
  );
}

/* ═══════════════════════════════════════════════════════
   MAIN PORTFOLIO SITE COMPONENT
   ═══════════════════════════════════════════════════════ */

export function PortfolioSite({ data, onEdit, onDownloadJson }: PortfolioSiteProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Dynamic font loading
  useEffect(() => {
    if (data.fontFamily && googleFontMap[data.fontFamily]) {
      const existingLink = document.querySelector(`link[data-portfolio-font]`);
      if (existingLink) existingLink.remove();

      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = `https://fonts.googleapis.com/css2?family=${googleFontMap[data.fontFamily]}&display=swap`;
      link.setAttribute('data-portfolio-font', 'true');
      document.head.appendChild(link);
    }
  }, [data.fontFamily]);

  // Set page title
  useEffect(() => {
    const name = data.fullName || data.brandName || 'Portfolio';
    const tagline = data.tagline ? ` — ${data.tagline}` : '';
    document.title = `${name}${tagline}`;
  }, [data.fullName, data.brandName, data.tagline]);

  const accentGradient = `linear-gradient(135deg, ${data.accentColor}, ${data.secondaryAccentColor})`;
  const fontStack = `'${data.fontFamily}', system-ui, -apple-system, sans-serif`;

  return (
    <div
      ref={containerRef}
      className="min-h-screen bg-dark text-text-primary"
      style={{ fontFamily: fontStack }}
    >
      <FloatingToolbar onEdit={onEdit} onDownload={onDownloadJson} accent={accentGradient} />

      <SiteNavbar data={data} accent={accentGradient} />

      <SiteHero data={data} accent={accentGradient} />

      <SiteMarquee data={data} />

      <SiteAbout data={data} accent={accentGradient} />

      <SiteServices data={data} accent={accentGradient} />

      <SiteWork data={data} accent={accentGradient} />

      <SiteTestimonials data={data} accent={accentGradient} />

      <SiteContact data={data} accent={accentGradient} />

      <SiteFooter data={data} accent={accentGradient} />
    </div>
  );
}
