export interface StatItem {
  number: string;
  label: string;
}

export interface SkillCard {
  iconType: string;
  title: string;
  description: string;
}

export interface ServiceItem {
  iconType: string;
  title: string;
  description: string;
  features: string[];
}

export interface ProjectItem {
  title: string;
  category: string;
  description: string;
  tags: string[];
  liveUrl: string;
  githubUrl: string;
  imageUrl: string;
  gradientColor: string;
  featured: boolean;
}

export interface TestimonialItem {
  name: string;
  role: string;
  company: string;
  content: string;
  rating: number;
  avatarUrl: string;
}

export interface SocialLink {
  platform: string;
  url: string;
}

export interface PortfolioFormData {
  // Step 1: Identity & Branding
  fullName: string;
  brandName: string;
  logoInitials: string;
  tagline: string;
  profilePhotoUrl: string;

  // Step 2: Hero Section
  heroHeadlineLine1: string;
  heroHeadlineLine2: string;
  heroHeadlineLine3: string;
  heroSubtitle: string;
  availabilityStatus: string;
  availabilityText: string;
  primaryCtaText: string;
  primaryCtaLink: string;
  secondaryCtaText: string;
  secondaryCtaLink: string;
  stats: StatItem[];

  // Step 3: Marquee / Scrolling Ticker
  marqueeItems: string[];

  // Step 4: About Section
  aboutHeading: string;
  aboutHeadingHighlight: string;
  aboutParagraph1: string;
  aboutParagraph2: string;
  aboutParagraph3: string;
  location: string;
  yearsExperience: string;
  techStack: string[];
  skillCards: SkillCard[];

  // Step 5: Services Section
  servicesHeading: string;
  servicesHeadingHighlight: string;
  servicesSubtitle: string;
  services: ServiceItem[];

  // Step 6: Work / Portfolio Section
  workHeading: string;
  workHeadingHighlight: string;
  workSubtitle: string;
  notionPortfolioLink: string;
  projects: ProjectItem[];

  // Step 7: Testimonials Section
  testimonialsHeading: string;
  testimonialsHeadingHighlight: string;
  testimonialsSubtitle: string;
  testimonials: TestimonialItem[];

  // Step 8: Contact Section
  contactHeading: string;
  contactHeadingHighlight: string;
  contactSubtitle: string;
  contactEmail: string;
  contactPhone: string;
  contactLocation: string;
  socialLinks: SocialLink[];
  contactFormEnabled: boolean;

  // Step 9: Footer Section
  footerTagline: string;
  footerCopyright: string;
  footerDesignCredit: string;

  // Step 10: Theme & Customization
  accentColor: string;
  secondaryAccentColor: string;
  fontFamily: string;
  darkMode: boolean;

  // Resume / CV
  resumeUrl: string;
}

export const defaultFormData: PortfolioFormData = {
  fullName: '',
  brandName: '',
  logoInitials: '',
  tagline: '',
  profilePhotoUrl: '',

  heroHeadlineLine1: '',
  heroHeadlineLine2: '',
  heroHeadlineLine3: '',
  heroSubtitle: '',
  availabilityStatus: 'available',
  availabilityText: 'Available for freelance work',
  primaryCtaText: 'View My Work',
  primaryCtaLink: '#work',
  secondaryCtaText: 'Learn More',
  secondaryCtaLink: '#about',
  stats: [
    { number: '', label: '' },
    { number: '', label: '' },
    { number: '', label: '' },
    { number: '', label: '' },
  ],

  marqueeItems: [],

  aboutHeading: 'Passionate about creating',
  aboutHeadingHighlight: 'meaningful experiences',
  aboutParagraph1: '',
  aboutParagraph2: '',
  aboutParagraph3: '',
  location: '',
  yearsExperience: '',
  techStack: [],
  skillCards: [
    { iconType: 'code', title: '', description: '' },
    { iconType: 'palette', title: '', description: '' },
    { iconType: 'zap', title: '', description: '' },
    { iconType: 'globe', title: '', description: '' },
  ],

  servicesHeading: 'What I',
  servicesHeadingHighlight: 'do best',
  servicesSubtitle: '',
  services: [
    { iconType: 'monitor', title: '', description: '', features: ['', '', '', ''] },
    { iconType: 'smartphone', title: '', description: '', features: ['', '', '', ''] },
    { iconType: 'layers', title: '', description: '', features: ['', '', '', ''] },
    { iconType: 'trending-up', title: '', description: '', features: ['', '', '', ''] },
  ],

  workHeading: 'Selected',
  workHeadingHighlight: 'works',
  workSubtitle: '',
  notionPortfolioLink: '',
  projects: [
    { title: '', category: '', description: '', tags: [], liveUrl: '', githubUrl: '', imageUrl: '', gradientColor: 'from-violet-500 to-purple-600', featured: true },
    { title: '', category: '', description: '', tags: [], liveUrl: '', githubUrl: '', imageUrl: '', gradientColor: 'from-pink-500 to-rose-600', featured: true },
  ],

  testimonialsHeading: 'What clients',
  testimonialsHeadingHighlight: 'say',
  testimonialsSubtitle: '',
  testimonials: [
    { name: '', role: '', company: '', content: '', rating: 5, avatarUrl: '' },
    { name: '', role: '', company: '', content: '', rating: 5, avatarUrl: '' },
    { name: '', role: '', company: '', content: '', rating: 5, avatarUrl: '' },
  ],

  contactHeading: "Let's work",
  contactHeadingHighlight: 'together',
  contactSubtitle: '',
  contactEmail: '',
  contactPhone: '',
  contactLocation: '',
  socialLinks: [
    { platform: 'GitHub', url: '' },
    { platform: 'LinkedIn', url: '' },
    { platform: 'Twitter', url: '' },
    { platform: 'Dribbble', url: '' },
  ],
  contactFormEnabled: true,

  footerTagline: '',
  footerCopyright: '',
  footerDesignCredit: '',

  accentColor: '#8b5cf6',
  secondaryAccentColor: '#ec4899',
  fontFamily: 'Inter',
  darkMode: true,

  resumeUrl: '',
};
